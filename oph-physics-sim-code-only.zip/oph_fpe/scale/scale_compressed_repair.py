from __future__ import annotations

import csv
import json
import math
from pathlib import Path
from typing import Any

import numpy as np

from oph_fpe.bulk.cap_profile_geometry import (
    cap_profile_for_h3_point,
    caps_to_h3_minimal_receipt,
    sample_round_caps,
)
from oph_fpe.bulk.cap_normals import cap_normals
from oph_fpe.bulk.h3_chart import h3_distance_matrix, random_h3_points
from oph_fpe.cmb_fossil.screen_covariance import (
    apply_low_l_repair_suppression,
    apply_parity_term,
    cl_oph_screen,
)
from oph_fpe.cosmology.cmb_compare import cmb_lite_comparison_report, load_planck_tt_binned
from oph_fpe.cosmology.repair_scale_closure import repair_scale_closure_report


def scale_compressed_repair_run(
    out_dir: Path,
    *,
    repair_rounds: int = 24,
    object_count: int = 48,
    particle_count: int = 6,
    cap_axis_count: int = 24,
    theta_values: tuple[float, ...] = (0.35, 0.55, 0.75, 1.0, 1.25),
    ell_max: int = 256,
    seed: int = 20260610,
    planck_tt: Path | None = None,
) -> dict[str, Any]:
    """Run a scale-compressed OPH repair-round branch diagnostic.

    This is a logical 24-round operator: each round represents one multiplicative
    scale repair, not a literal increase to 10^122 finite patches. The output is
    a preview/certificate lane for the repair-depth hypothesis. It deliberately
    does not mark strict neutral 3D bulk or physical CMB as passed.
    """

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    closure = repair_scale_closure_report(
        repair_rounds=int(repair_rounds),
        regulator_patch_counts=(4_096, 65_536, 262_144, 1_048_576),
    )
    outputs = closure["closure_outputs"]
    g_abs = float(outputs["local_repair_contraction_abs_gprime"])
    q_round = float(outputs["scale_factor_per_round_q"])
    eta = float(outputs["eta_R_p_over_2m"])
    n_s = float(outputs["n_s_p_over_2m"])
    ansatz_capacity = outputs.get(
        "capacity_implied_by_declared_repair_depth_ansatz",
        outputs.get("capacity_predicted_from_local_P"),
    )
    ansatz_rel_error = outputs.get(
        "relative_error_ansatz_capacity_vs_declared_N_CRC",
        outputs.get("relative_error_gprime_vs_N_CRC_closure"),
    )

    round_rows = _round_trace(int(repair_rounds), g_abs=g_abs, q_round=q_round, eta=eta)
    _write_rows(out / "scale_compressed_repair_rounds.csv", round_rows)

    caps = sample_round_caps(cap_axis_count, theta_values, seed=seed)
    normals = cap_normals(caps)
    h3_points = random_h3_points(object_count, seed=seed + 11, radius=1.35)
    object_rows = _object_rows(h3_points, normals, softness=0.25)
    _write_rows(out / "scale_compressed_h3_objects.csv", object_rows)

    h3_receipt = caps_to_h3_minimal_receipt(
        axis_count=cap_axis_count,
        theta_values=theta_values,
        object_count=min(16, max(4, object_count // 2)),
        object_radius=1.25,
        fit_radius=2.0,
        softness=0.25,
        restarts=12,
        seed=seed + 101,
        max_median_error=0.02,
    )
    object_chart = _object_chart_report(object_rows, h3_receipt)
    particles = _particle_rows(h3_points, particle_count=particle_count, repair_rounds=repair_rounds, seed=seed + 29)
    _write_rows(out / "scale_compressed_particles.csv", particles)
    particle_report = _particle_report(particles)

    cl_report = _cl_report(ell_max=ell_max, eta=eta)
    _write_cl_rows(out / "scale_compressed_screen_cl.csv", cl_report["fields"]["scale_compressed_repair"]["spectrum"])
    cmb_lite = {}
    if planck_tt is not None and Path(planck_tt).exists():
        cmb_lite = cmb_lite_comparison_report(
            cl_report,
            load_planck_tt_binned(Path(planck_tt)),
            benchmark_label="Planck2018_TT_binned",
            source_url=str(planck_tt),
            field_names=["scale_compressed_repair"],
        )

    branch_report = {
        "mode": "oph_scale_compressed_repair_round_branch_v0",
        "repair_scale_closure": closure,
        "logical_repair_rounds": int(repair_rounds),
        "scale_compressed_operator_receipt": True,
        "repair_round_trace_receipt": bool(len(round_rows) == int(repair_rounds) + 1),
        "cmb_parameter_readouts": {
            "eta_R": eta,
            "n_s": n_s,
            "q_IR": 0.25,
            "ell_IR": 32.0,
            "N_CRC_implied_by_declared_repair_depth_ansatz": ansatz_capacity,
            "N_CRC_predicted_from_P": ansatz_capacity,
            "N_CRC_declared": closure["global_capacity_inputs"]["N_CRC"],
            "relative_error_ansatz_capacity_vs_declared_N_CRC": ansatz_rel_error,
            "relative_error_gprime_vs_N_CRC": ansatz_rel_error,
            "repair_depth_ansatz_compatibility_note": (
                "N_CRC_predicted_from_P is a legacy alias. The canonical value is implied by the declared "
                "repair-depth ansatz; P/N do not independently set a dimensionful scale."
            ),
        },
        "h3_preview": {
            "object_count": int(object_count),
            "cap_count": int(len(caps)),
            "cap_profile_receipt": bool(h3_receipt.get("S2_CAP_PROFILE_TO_H3_RECEIPT", False)),
            "populated_h3_preview_receipt": bool(
                h3_receipt.get("S2_CAP_PROFILE_TO_H3_RECEIPT", False) and object_count >= 8
            ),
            "strict_neutral_third_person_bulk_established": False,
            "claim_boundary": (
                "Objects are generated by the scale-compressed H3 cap-profile branch. This previews "
                "paper-side populated H3 behavior, but it is not a blind neutral reconstruction from "
                "uncompressed observer records."
            ),
        },
        "particle_preview": {
            "particle_worldline_count": int(particle_count),
            "particle_preview_receipt": bool(particle_count > 0),
            "production_particle_matter_receipt": False,
        },
        "cmb_screen_scaffold": {
            "ell_max": int(ell_max),
            "screen_cl_written": True,
            "cmb_lite_written": bool(cmb_lite),
            "physical_cmb_prediction": False,
            "claim_boundary": (
                "Scale-compressed screen C_l scaffold with OPH tilt. Acoustic peaks require the "
                "Boltzmann/CAMB transfer lane and finite kernel certificates."
            ),
        },
        "physical_cmb_prediction": False,
        "strict_neutral_bulk": False,
        "bulk_3d_established": False,
        "claim_boundary": (
            "Scale-compressed logical repair-round diagnostic. This directly simulates 24 logical scale "
            "rounds using the repair-depth closure, producing CMB parameter readouts and a populated H3 "
            "preview. It is not a literal 10^122-cell run, not a proof that 24 rounds are selected by a "
            "finite theorem, not strict neutral third-person bulk, and not a physical CMB prediction."
        ),
    }

    (out / "repair_scale_closure_report.json").write_text(json.dumps(closure, indent=2, default=str), encoding="utf-8")
    (out / "scale_compressed_repair_report.json").write_text(
        json.dumps(branch_report, indent=2, default=str),
        encoding="utf-8",
    )
    (out / "scale_compressed_repair_report.md").write_text(_markdown_report(branch_report), encoding="utf-8")
    (out / "caps_to_h3_minimal_report.json").write_text(json.dumps(h3_receipt, indent=2, default=str), encoding="utf-8")
    (out / "observer_chart_object_h3_scale_compressed_report.json").write_text(
        json.dumps(object_chart, indent=2, default=str),
        encoding="utf-8",
    )
    (out / "scale_compressed_particle_report.json").write_text(
        json.dumps(particle_report, indent=2, default=str),
        encoding="utf-8",
    )
    (out / "cl_comparison_report.json").write_text(json.dumps(cl_report, indent=2, default=str), encoding="utf-8")
    if cmb_lite:
        (out / "cmb_lite_comparison_report.json").write_text(
            json.dumps(cmb_lite, indent=2, default=str),
            encoding="utf-8",
        )
    return branch_report


def _round_trace(repair_rounds: int, *, g_abs: float, q_round: float, eta: float) -> list[dict[str, Any]]:
    rows = []
    for round_index in range(int(repair_rounds) + 1):
        length_ratio = float(q_round**round_index)
        capacity_ratio = float(length_ratio * length_ratio)
        mismatch_residual = float(g_abs**round_index)
        release_weight = float(1.0 - math.exp(-eta * round_index))
        rows.append(
            {
                "logical_round": int(round_index),
                "length_ratio": length_ratio,
                "capacity_ratio": capacity_ratio,
                "mismatch_residual": mismatch_residual,
                "record_release_weight": release_weight,
                "claim_boundary": "logical scale-compressed round, not literal patch-count growth",
            }
        )
    return rows


def _object_rows(points: np.ndarray, normals: np.ndarray, *, softness: float) -> list[dict[str, Any]]:
    distances = h3_distance_matrix(points)
    rows = []
    for idx, point in enumerate(points):
        profile = cap_profile_for_h3_point(point, normals, softness=softness)
        nearest = np.sort(distances[idx])[1:6] if distances.shape[0] > 1 else np.zeros(0)
        rows.append(
            {
                "object_id": f"sc_object_{idx:04d}",
                "h3_t": float(point[0]),
                "h3_x": float(point[1]),
                "h3_y": float(point[2]),
                "h3_z": float(point[3]),
                "mean_cap_response": float(np.mean(profile)),
                "std_cap_response": float(np.std(profile)),
                "mean_nearest_h3_distance": float(np.mean(nearest)) if nearest.size else 0.0,
                "support_visible": True,
            }
        )
    return rows


def _object_chart_report(object_rows: list[dict[str, Any]], h3_receipt: dict[str, Any]) -> dict[str, Any]:
    count = len(object_rows)
    return {
        "mode": "scale_compressed_observer_chart_object_h3_population",
        "observer_chart_object_h3_receipt": bool(count > 0 and h3_receipt.get("S2_CAP_PROFILE_TO_H3_RECEIPT", False)),
        "scale_compressed_observer_chart_bulk_population_receipt": bool(
            count >= 8 and h3_receipt.get("S2_CAP_PROFILE_TO_H3_RECEIPT", False)
        ),
        "observer_chart_bulk_population_receipt": False,
        "localized_nonboundary_bulk_population_receipt": False,
        "object_count": int(count),
        "localized_object_count": int(count),
        "localized_not_boundary_object_count": int(count),
        "median_h3_compactness_normalized": _median(row["mean_nearest_h3_distance"] for row in object_rows),
        "median_s2_boundary_compactness_normalized": None,
        "median_shuffled_h3_compactness_normalized": None,
        "sample_objects": object_rows[: min(16, count)],
        "claim_boundary": (
            "Scale-compressed H3 object preview. Standard observer_chart_bulk_population_receipt is kept "
            "false so this branch does not masquerade as an uncompressed finite observer-record bulk proof."
        ),
    }


def _particle_rows(
    points: np.ndarray,
    *,
    particle_count: int,
    repair_rounds: int,
    seed: int,
) -> list[dict[str, Any]]:
    rng = np.random.default_rng(seed)
    rows = []
    count = min(int(particle_count), max(0, points.shape[0] // 2))
    for particle_id in range(count):
        base = points[particle_id]
        direction = rng.normal(size=3)
        direction /= max(float(np.linalg.norm(direction)), 1.0e-12)
        for round_index in range(int(repair_rounds) + 1):
            drift = 0.015 * round_index * direction
            rows.append(
                {
                    "particle_id": f"sc_particle_{particle_id:03d}",
                    "logical_round": int(round_index),
                    "h3_t": float(base[0]),
                    "h3_x": float(base[1] + drift[0]),
                    "h3_y": float(base[2] + drift[1]),
                    "h3_z": float(base[3] + drift[2]),
                    "sector_class": ["S3:transposition", "S3:threecycle"][particle_id % 2],
                    "localized": True,
                    "persistent": True,
                }
            )
    return rows


def _particle_report(rows: list[dict[str, Any]]) -> dict[str, Any]:
    particle_ids = sorted({row["particle_id"] for row in rows})
    return {
        "mode": "scale_compressed_particle_worldline_preview",
        "worldline_count": len(particle_ids),
        "observation_count": len(rows),
        "particle_preview_receipt": bool(particle_ids),
        "production_particle_matter_receipt": False,
        "claim_boundary": (
            "Scale-compressed localized defect/worldline preview. Not production particle emergence because "
            "transport/fusion/scattering were not generated by uncompressed OPH repair dynamics."
        ),
    }


def _cl_report(*, ell_max: int, eta: float) -> dict[str, Any]:
    ell = np.arange(2, int(ell_max) + 1, dtype=float)
    cl = cl_oph_screen(ell, A=1.0, eta=float(eta), ell_cap=max(3000.0, float(ell_max)))
    cl = apply_low_l_repair_suppression(cl, ell, q_ir=0.25, ell_ir=32.0)
    cl = apply_parity_term(cl, ell, eps_p=0.0, ell_p=30.0)
    d_ell = ell * (ell + 1.0) * cl / (2.0 * math.pi)
    spectrum = [
        {"ell": int(left), "C_ell": float(cval), "D_ell": float(dval)}
        for left, cval, dval in zip(ell, cl, d_ell, strict=False)
    ]
    return {
        "mode": "scale_compressed_repair_screen_cl",
        "ell_max": int(ell_max),
        "estimator": "analytic_scale_compressed_repair_screen_covariance",
        "point_count": None,
        "gate_report": {"allowed": True, "source": "scale_compressed_repair_round_branch"},
        "fields": {
            "scale_compressed_repair": {
                "eta_R": float(eta),
                "n_s_proxy": float(1.0 - eta),
                "spectrum": spectrum,
            }
        },
        "physical_cmb_prediction": False,
        "claim_boundary": (
            "Screen-level scalar C_l scaffold from the scale-compressed repair branch. It is not an "
            "acoustic TT prediction until propagated through Boltzmann transfer."
        ),
    }


def _write_cl_rows(path: Path, rows: list[dict[str, Any]]) -> None:
    _write_rows(path, rows)


def _write_rows(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _median(values: Any) -> float | None:
    parsed = [float(value) for value in values if isinstance(value, (int, float))]
    return float(np.median(parsed)) if parsed else None


def _markdown_report(report: dict[str, Any]) -> str:
    params = report["cmb_parameter_readouts"]
    h3 = report["h3_preview"]
    return "\n".join(
        [
            "# OPH Scale-Compressed Repair Branch",
            "",
            str(report["claim_boundary"]),
            "",
            "## CMB Readouts",
            "",
            f"- eta_R: `{params['eta_R']:.12g}`",
            f"- n_s: `{params['n_s']:.12g}`",
            f"- q_IR: `{params['q_IR']}`",
            f"- ell_IR: `{params['ell_IR']}`",
            "- N_CRC implied by repair-depth ansatz: "
            f"`{params['N_CRC_implied_by_declared_repair_depth_ansatz']:.12e}`",
            "",
            "## H3 Preview",
            "",
            f"- object count: `{h3['object_count']}`",
            f"- cap count: `{h3['cap_count']}`",
            f"- cap-profile H3 receipt: `{str(h3['cap_profile_receipt']).lower()}`",
            f"- populated H3 preview receipt: `{str(h3['populated_h3_preview_receipt']).lower()}`",
            f"- strict neutral third-person bulk: `{str(h3['strict_neutral_third_person_bulk_established']).lower()}`",
            "",
        ]
    )
