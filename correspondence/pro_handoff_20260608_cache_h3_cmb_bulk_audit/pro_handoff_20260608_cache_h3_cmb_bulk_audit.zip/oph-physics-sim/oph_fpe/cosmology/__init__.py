"""Cosmology helpers with lazy public exports.

The package intentionally avoids eager submodule imports. Several OPH-FPE
handoff bundles include only the modules needed for one diagnostic lane; eager
imports made unrelated missing modules break otherwise-valid reproduction
commands such as importing the CAMB baseline adapter.
"""

from __future__ import annotations

from typing import Any

_EXPORTS = {
    "anomaly_background_rhs": ("oph_fpe.cosmology.anomaly_fluid", "anomaly_background_rhs"),
    "anomaly_perturbation_rhs": ("oph_fpe.cosmology.anomaly_fluid", "anomaly_perturbation_rhs"),
    "exchange_closure_report": ("oph_fpe.cosmology.anomaly_fluid", "exchange_closure_report"),
    "angular_power_report": ("oph_fpe.cosmology.angular_power", "angular_power_report"),
    "background_adapter_status": ("oph_fpe.cosmology.background_adapter", "background_adapter_status"),
    "estimate_b_a_grid": ("oph_fpe.cosmology.ba_parent", "estimate_b_a_grid"),
    "oph_boltzmann_input_report": ("oph_fpe.cosmology.boltzmann_inputs", "oph_boltzmann_input_report"),
    "write_oph_boltzmann_input_report": ("oph_fpe.cosmology.boltzmann_inputs", "write_oph_boltzmann_input_report"),
    "LambdaCDMParameters": ("oph_fpe.cosmology.camb_adapter", "LambdaCDMParameters"),
    "camb_lcdm_baseline_report": ("oph_fpe.cosmology.camb_adapter", "camb_lcdm_baseline_report"),
    "compare_camb_tt_to_benchmark": ("oph_fpe.cosmology.camb_adapter", "compare_camb_tt_to_benchmark"),
    "write_camb_lcdm_baseline_report": ("oph_fpe.cosmology.camb_adapter", "write_camb_lcdm_baseline_report"),
    "collect_cl_runs": ("oph_fpe.cosmology.cl_ensemble", "collect_cl_runs"),
    "cl_ensemble_report": ("oph_fpe.cosmology.cl_ensemble", "cl_ensemble_report"),
    "write_cl_ensemble_report": ("oph_fpe.cosmology.cl_ensemble", "write_cl_ensemble_report"),
    "cmb_lite_comparison_report": ("oph_fpe.cosmology.cmb_compare", "cmb_lite_comparison_report"),
    "load_planck_tt_binned": ("oph_fpe.cosmology.cmb_compare", "load_planck_tt_binned"),
    "write_cmb_lite_comparison": ("oph_fpe.cosmology.cmb_compare", "write_cmb_lite_comparison"),
    "collect_comparable_runs": ("oph_fpe.cosmology.comparable_data", "collect_comparable_runs"),
    "comparable_data_report": ("oph_fpe.cosmology.comparable_data", "comparable_data_report"),
    "write_comparable_data_package": ("oph_fpe.cosmology.comparable_data", "write_comparable_data_package"),
    "measurement_target": ("oph_fpe.cosmology.data_targets", "measurement_target"),
    "target_registry": ("oph_fpe.cosmology.data_targets", "target_registry"),
    "write_freezeout_products": ("oph_fpe.cosmology.freezeout", "write_freezeout_products"),
    "galaxy_proxy_receipt": ("oph_fpe.cosmology.galaxy_proxy", "galaxy_proxy_receipt"),
    "load_static_galaxy_dataset": ("oph_fpe.cosmology.galaxy_static", "load_static_galaxy_dataset"),
    "btfr_prediction_from_rar_fit": (
        "oph_fpe.cosmology.galaxy_static",
        "btfr_prediction_from_rar_fit",
    ),
    "nu_oph": ("oph_fpe.cosmology.galaxy_proxy", "nu_oph"),
    "rar_curve": ("oph_fpe.cosmology.galaxy_proxy", "rar_curve"),
    "static_galaxy_measurement_report": ("oph_fpe.cosmology.galaxy_static", "static_galaxy_measurement_report"),
    "static_galaxy_holdout_report": ("oph_fpe.cosmology.galaxy_static", "static_galaxy_holdout_report"),
    "write_static_galaxy_measurement_report": (
        "oph_fpe.cosmology.galaxy_static",
        "write_static_galaxy_measurement_report",
    ),
    "oph_cmb_stress_adapter_report": ("oph_fpe.cosmology.oph_cmb_adapter", "oph_cmb_stress_adapter_report"),
    "cosmo_proxy_receipt": ("oph_fpe.cosmology.proxy_pipeline", "cosmo_proxy_receipt"),
}

__all__ = sorted(_EXPORTS)


def __getattr__(name: str) -> Any:
    if name not in _EXPORTS:
        raise AttributeError(name)
    module_name, attr_name = _EXPORTS[name]
    from importlib import import_module

    module = import_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value
