# Small OPH Universe v1: Exact Evidence Runbook

## Claim boundary

This fixture can establish an exact fixed-cutoff finite-consensus and holonomy-obstruction receipt. It cannot establish endogenous modular flow, the BW `2π` coefficient, Lorentz symmetry, H3 bulk, particles, or cosmology.

## Run

```bash
python3 small_oph_universe_v1.py \
  --seed 20260620 \
  --schedule-replays 16 \
  --out runs/small_oph_universe_v1
sha256sum -c runs/small_oph_universe_v1/SHA256.txt
```

## Frozen model

- graph: 12-vertex icosahedral graph;
- visible interface alphabet: `Z2`;
- boundary: patch 0 pinned;
- local repair: a non-root patch copies the parent-consistent packet;
- acceptance: strict decrease only;
- audit space: all `2^11 = 2048` root-pinned visible states;
- controls: a consistent zero-holonomy instance and a one-edge frustrated instance;
- schedule test: 16 fair schedules per initial state.

## Required exact success receipt

```text
strict_descent_violation_count == 0
accepted_phi_increase_violation_count == 0
disjoint_commutation_violation_count == 0
local_diamond_or_schedule_confluence_violation_count == 0
repair_completeness_violation_count == 0
global_consistent_state_count == 1
unique_terminal_normal_form_count == 1
terminal_phi == 0
FINITE_CONSENSUS_THEOREM_RECEIPT == true
```

## Required obstruction control

```text
global_consistent_state_count == 0
nonzero_holonomy_cycle_count > 0
terminal_phi > 0
HOLONOMY_OBSTRUCTION_RECEIPT == true
```

## Reference result for seed 20260620

```text
states exhaustively enumerated: 2048
enabled repair events checked: 11264
schedule replays per state: 16
all exact-branch violation counts: 0
exact branch terminal Phi: 0
frustrated branch terminal Phi: 1
bundle receipt: true
```

## Next evidence steps

1. Add exact record projectors and checkpoint continuation with held-out boundary prediction.
2. Build a cap-local MaxEnt operator state without geometry or `2π` in the state builder.
3. Derive a second modular generator from lagged transition data.
4. Infer the cap-flow coefficient continuously, then compare it with `1`, `π`, `2π`, and `4π`.
5. Only after those pass, test ordered cap-pair rigidity, Lorentz algebra closure, and refinement.
