#!/usr/bin/env python3
"""Exact Small OPH Universe v1 calibration.

This is a finite consensus/holonomy evidence fixture, not evidence for Lorentz,
H3, particles, or cosmology. It uses the 12-vertex icosahedral graph, a Z2
visible packet on each patch, a pinned root boundary, a local parent-copy repair
law, exhaustive state enumeration, randomized fair schedule replays, and a
frustrated holonomy control.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import networkx as nx
import numpy as np


@dataclass(frozen=True)
class Universe:
    graph: nx.Graph
    root: int
    parent: dict[int, int]
    depth: dict[int, int]
    target: tuple[int, ...]
    offsets: dict[tuple[int, int], int]
    weights: dict[tuple[int, int], int]
    tree_edges: frozenset[tuple[int, int]]


def edge_key(u: int, v: int) -> tuple[int, int]:
    return (u, v) if u < v else (v, u)


def stable_hash(obj: object) -> str:
    payload = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(payload).hexdigest()


def build_universe(seed: int, *, frustrate: bool = False) -> Universe:
    g = nx.icosahedral_graph()
    root = 0
    parent: dict[int, int] = {}
    depth = {root: 0}
    q: deque[int] = deque([root])
    while q:
        u = q.popleft()
        for v in sorted(g.neighbors(u)):
            if v in depth:
                continue
            depth[v] = depth[u] + 1
            parent[v] = u
            q.append(v)

    rng = np.random.default_rng(seed)
    target = [0] + [int(x) for x in rng.integers(0, 2, size=g.number_of_nodes() - 1)]
    offsets = {edge_key(u, v): target[u] ^ target[v] for u, v in g.edges()}
    tree_edges = frozenset(edge_key(p, v) for v, p in parent.items())

    non_tree = sorted(set(offsets) - set(tree_edges))
    flipped_edge = None
    if frustrate:
        # Flip a deterministic non-tree constraint, creating a cycle obstruction.
        flipped_edge = non_tree[seed % len(non_tree)]
        offsets[flipped_edge] ^= 1

    max_depth = max(depth.values())
    base = 64
    weights: dict[tuple[int, int], int] = {}
    for e in offsets:
        if e in tree_edges:
            child = e[0] if parent.get(e[0]) == e[1] else e[1]
            weights[e] = base ** (max_depth - depth[child] + 1)
        else:
            weights[e] = 1

    u = Universe(
        graph=g,
        root=root,
        parent=parent,
        depth=depth,
        target=tuple(target),
        offsets=offsets,
        weights=weights,
        tree_edges=tree_edges,
    )
    object.__setattr__(u, "flipped_edge", flipped_edge)  # report-only convenience
    return u


def mismatch(u: Universe, state: tuple[int, ...], e: tuple[int, int]) -> int:
    a, b = e
    return int((state[a] ^ state[b]) != u.offsets[e])


def phi(u: Universe, state: tuple[int, ...]) -> int:
    return sum(u.weights[e] * mismatch(u, state, e) for e in u.offsets)


def globally_consistent(u: Universe, state: tuple[int, ...]) -> bool:
    return all(mismatch(u, state, e) == 0 for e in u.offsets)


def enabled_repairs(u: Universe, state: tuple[int, ...]) -> list[int]:
    out = []
    for v, p in u.parent.items():
        expected = state[p] ^ u.offsets[edge_key(p, v)]
        if state[v] != expected:
            out.append(v)
    return out


def apply_repair(u: Universe, state: tuple[int, ...], v: int) -> tuple[int, ...]:
    p = u.parent[v]
    expected = state[p] ^ u.offsets[edge_key(p, v)]
    if state[v] == expected:
        return state
    new = list(state)
    new[v] = expected
    return tuple(new)


def normalize(u: Universe, state: tuple[int, ...], schedule: Iterable[int], *, max_sweeps: int = 32) -> tuple[tuple[int, ...], int]:
    s = state
    steps = 0
    order = tuple(schedule)
    for _ in range(max_sweeps):
        changed = False
        for v in order:
            if v == u.root:
                continue
            nxt = apply_repair(u, s, v)
            if nxt != s:
                s = nxt
                steps += 1
                changed = True
        if not changed:
            return s, steps
    raise RuntimeError("normalization did not terminate")


def fair_schedules(u: Universe, seed: int, count: int) -> list[tuple[int, ...]]:
    nodes = sorted(u.parent)
    schedules = [
        tuple(nodes),
        tuple(reversed(nodes)),
        tuple(sorted(nodes, key=lambda x: (u.depth[x], x))),
        tuple(sorted(nodes, key=lambda x: (-u.depth[x], x))),
    ]
    rng = np.random.default_rng(seed + 991)
    while len(schedules) < count:
        schedules.append(tuple(int(x) for x in rng.permutation(nodes)))
    return schedules[:count]


def all_root_pinned_states(u: Universe) -> Iterable[tuple[int, ...]]:
    n = u.graph.number_of_nodes()
    for tail in itertools.product((0, 1), repeat=n - 1):
        yield (0,) + tail


def cycle_holonomies(u: Universe) -> list[dict[str, object]]:
    rows = []
    for cycle in nx.cycle_basis(u.graph, root=u.root):
        h = 0
        edges = []
        for a, b in zip(cycle, cycle[1:] + cycle[:1]):
            e = edge_key(a, b)
            edges.append(e)
            h ^= u.offsets[e]
        rows.append({"cycle": cycle, "edges": edges, "holonomy_z2": h})
    return rows


def audit(u: Universe, *, seed: int, schedule_replays: int) -> dict[str, object]:
    schedules = fair_schedules(u, seed, schedule_replays)
    state_count = 0
    strict_descent_violations = 0
    global_phi_increase_violations = 0
    disjoint_commutation_violations = 0
    local_diamond_violations = 0
    terminal_count = 0
    globally_consistent_terminal_count = 0
    unique_terminal_states: set[tuple[int, ...]] = set()
    max_steps = 0
    total_enabled = 0

    # Precompute a canonical normalizer for diamond joins.
    canonical_schedule = tuple(sorted(u.parent, key=lambda x: (u.depth[x], x)))

    for s in all_root_pinned_states(u):
        state_count += 1
        enabled = enabled_repairs(u, s)
        total_enabled += len(enabled)
        if not enabled:
            terminal_count += 1
            globally_consistent_terminal_count += int(globally_consistent(u, s))

        for v in enabled:
            nxt = apply_repair(u, s, v)
            d = phi(u, nxt) - phi(u, s)
            if d >= 0:
                strict_descent_violations += 1
            if d > 0:
                global_phi_increase_violations += 1

        for i, v in enumerate(enabled):
            for w in enabled[i + 1 :]:
                # Disjoint means neither node is the other's parent and they do not share an edge.
                disjoint = (
                    u.parent.get(v) != w
                    and u.parent.get(w) != v
                    and not u.graph.has_edge(v, w)
                )
                svw = apply_repair(u, apply_repair(u, s, v), w)
                swv = apply_repair(u, apply_repair(u, s, w), v)
                if disjoint and svw != swv:
                    disjoint_commutation_violations += 1
                n1, _ = normalize(u, apply_repair(u, s, v), canonical_schedule)
                n2, _ = normalize(u, apply_repair(u, s, w), canonical_schedule)
                if n1 != n2:
                    local_diamond_violations += 1

        terminals = set()
        for order in schedules:
            nf, steps = normalize(u, s, order)
            terminals.add(nf)
            max_steps = max(max_steps, steps)
        unique_terminal_states.update(terminals)
        if len(terminals) != 1:
            local_diamond_violations += 1

    hol = cycle_holonomies(u)
    zero_holonomy = all(row["holonomy_z2"] == 0 for row in hol)
    consistent_states = [s for s in all_root_pinned_states(u) if globally_consistent(u, s)]
    normal_form = next(iter(unique_terminal_states)) if len(unique_terminal_states) == 1 else None

    completeness_violations = 0
    for s in all_root_pinned_states(u):
        terminal = not enabled_repairs(u, s)
        if zero_holonomy and terminal != globally_consistent(u, s):
            completeness_violations += 1

    c0b = bool(
        zero_holonomy
        and strict_descent_violations == 0
        and global_phi_increase_violations == 0
        and disjoint_commutation_violations == 0
        and local_diamond_violations == 0
        and completeness_violations == 0
        and len(unique_terminal_states) == 1
        and len(consistent_states) == 1
    )
    obstruction_receipt = bool(
        (not zero_holonomy)
        and len(consistent_states) == 0
        and normal_form is not None
        and not globally_consistent(u, normal_form)
    )

    model_manifest = {
        "graph": "icosahedral_graph",
        "patch_count": u.graph.number_of_nodes(),
        "edge_count": u.graph.number_of_edges(),
        "group": "Z2",
        "root": u.root,
        "parent": u.parent,
        "depth": u.depth,
        "target": u.target,
        "offsets": {f"{a}-{b}": x for (a, b), x in sorted(u.offsets.items())},
        "weights": {f"{a}-{b}": x for (a, b), x in sorted(u.weights.items())},
        "tree_edges": sorted(u.tree_edges),
        "flipped_edge": getattr(u, "flipped_edge", None),
    }

    return {
        "schema": "small_oph_universe_exact_consensus_v1",
        "seed": seed,
        "model_manifest": model_manifest,
        "model_sha256": stable_hash(model_manifest),
        "state_count_exhaustively_enumerated": state_count,
        "enabled_repair_events_checked": total_enabled,
        "schedule_replays_per_state": schedule_replays,
        "strict_descent_violation_count": strict_descent_violations,
        "accepted_phi_increase_violation_count": global_phi_increase_violations,
        "disjoint_commutation_violation_count": disjoint_commutation_violations,
        "local_diamond_or_schedule_confluence_violation_count": local_diamond_violations,
        "repair_completeness_violation_count": completeness_violations,
        "terminal_state_count_in_state_space": terminal_count,
        "globally_consistent_terminal_count": globally_consistent_terminal_count,
        "global_consistent_state_count": len(consistent_states),
        "unique_terminal_normal_form_count": len(unique_terminal_states),
        "terminal_normal_form": normal_form,
        "terminal_phi": phi(u, normal_form) if normal_form is not None else None,
        "maximum_accepted_repairs_to_normal_form": max_steps,
        "cycle_basis_count": len(hol),
        "nonzero_holonomy_cycle_count": sum(int(row["holonomy_z2"] != 0) for row in hol),
        "cycle_holonomies": hol,
        "FINITE_CONSENSUS_THEOREM_RECEIPT": c0b,
        "HOLONOMY_OBSTRUCTION_RECEIPT": obstruction_receipt,
        "claim_boundary": (
            "Exact fixed-cutoff finite consensus/holonomy calibration only. "
            "It does not establish endogenous modular flow, 2pi, Lorentz symmetry, H3 bulk, particles, or cosmology."
        ),
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=20260620)
    ap.add_argument("--schedule-replays", type=int, default=16)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()

    args.out.mkdir(parents=True, exist_ok=True)
    exact = audit(build_universe(args.seed, frustrate=False), seed=args.seed, schedule_replays=args.schedule_replays)
    frustrated = audit(build_universe(args.seed, frustrate=True), seed=args.seed, schedule_replays=args.schedule_replays)
    bundle = {
        "schema": "small_oph_universe_evidence_bundle_v1",
        "exact_consensus": exact,
        "frustrated_control": frustrated,
        "bundle_receipt": bool(
            exact["FINITE_CONSENSUS_THEOREM_RECEIPT"]
            and frustrated["HOLONOMY_OBSTRUCTION_RECEIPT"]
        ),
    }
    bundle["bundle_sha256"] = stable_hash(bundle)
    (args.out / "small_oph_universe_evidence.json").write_text(
        json.dumps(bundle, indent=2, sort_keys=True), encoding="utf-8"
    )
    (args.out / "SHA256.txt").write_text(
        f"{hashlib.sha256((args.out / 'small_oph_universe_evidence.json').read_bytes()).hexdigest()}  small_oph_universe_evidence.json\n",
        encoding="utf-8",
    )
    print(json.dumps({
        "bundle_receipt": bundle["bundle_receipt"],
        "exact_C0b": exact["FINITE_CONSENSUS_THEOREM_RECEIPT"],
        "frustrated_holonomy_control": frustrated["HOLONOMY_OBSTRUCTION_RECEIPT"],
        "exact_states": exact["state_count_exhaustively_enumerated"],
        "exact_repair_events": exact["enabled_repair_events_checked"],
        "exact_terminal_phi": exact["terminal_phi"],
        "frustrated_terminal_phi": frustrated["terminal_phi"],
        "out": str(args.out),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
