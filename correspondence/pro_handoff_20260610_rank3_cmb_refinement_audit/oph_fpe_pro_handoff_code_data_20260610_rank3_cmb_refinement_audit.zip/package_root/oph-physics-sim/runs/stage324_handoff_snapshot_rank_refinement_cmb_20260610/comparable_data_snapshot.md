# OPH-FPE Comparable Data Snapshot

Comparable-data snapshot for current OPH-FPE receipts. Planck comparisons are shape-only C_l diagnostics with normalized axes and amplitude rescaling. OPH-screen CAMB transfer reports are solver scaffolds unless their screen-power input is simulator-derived and passes the finite eta/readiness gates. OPH-CMB anomaly-stress and inflation/CMB bridge reports are continuation diagnostics, not finite-lattice derivations. adapter values are finite-collar parent diagnostics, not CAMB/CLASS anomaly-module outputs. H3 values are internal modular-response-vs-control receipts. Defect values are screen/collar holonomy proxies. The top-level bulk flag requires every comparable seed in the selected run set to pass a non-boundary H3 object-population gate or strict neutral third-person bulk gate. H3 preview alone is reported separately. This is not a physical CMB prediction, not a P(k), not a Boltzmann likelihood, and not a completed particle-emergence result.

## Current Answer

Yes: the current simulator emits diagnostic, measurement-facing values and a theorem-assisted populated-H3 chart receipt on the paper route. No: it does not yet emit a physical CMB prediction, physical P(k), strict neutral third-person bulk reconstruction, or particle spectrum.

- comparable rows: 6
- theorem-assisted H3 bulk any/count: True / 1
- chart-level 3+1D any/count: True / 1
- strict neutral 3D bulk any/count: False / 0
- all selected rows bulk-established: False
- exact OPH target n_s: n/a
- exact OPH target CAMB IR shape correlation: n/a
- exact OPH target CAMB IR chi2/bin: n/a
- finite transition-clock n_s: 0.9664700435
- finite transition-clock kappa_rep: 2.592344557
- finite transition-clock certified count: 0
- finite transition required repair-step time for kappa=e: 45.77617281
- screen Planck-lite best shape correlation: 0.8039372295
- physical CMB prediction: False

## Support-Visible Lorentz Branch

- runs with Lorentz split receipts: 1
- chart-level conformal Lorentz receipts: 1
- BW automorphism sanity receipts: 1
- support-visible 3+1D Lorentz receipts: 1
- endogenous modular-generator receipts: 0
- paper-theorem 3D bulk-chart receipts: 1
- paper-theorem H3 spatial dimension mean: 3
- paper-theorem object-populated chart precursors: 0
- paper-theorem neutral populated bulk receipts: 0
- support-visible record H3 population receipts: 0
- support-visible defect H3 population receipts: 0
- support-visible populated-H3 bulk receipts: 0
- mean record-family H3 residual: n/a
- mean defect-cluster H3 residual: n/a
- paper-theorem-assisted H3 chart precursor receipts: 1
- paper-theorem-assisted populated H3 chart receipts: 1
- theorem-assisted H3 object-preview receipts: 1
- object H3 nonboundary population receipts: 1
- object bulk-population receipts: 1
- bulk-proof certificates: 1
- bulk-proof chart-level 3+1D counts: 1
- bulk-proof theorem-assisted H3 preview counts: 1
- bulk-proof theorem-assisted nonboundary H3 counts: 1
- bulk-proof legacy theorem-assisted populated H3 counts: 1
- bulk-proof strict neutral 3D counts: 0
- bulk-proof screen-CMB proxy counts: 1
- bulk-proof physical CMB counts: 0
- bulk-proof production particle counts: 0
- screen-proxy CMB receipts: 1
- bulk-established count: 1
- interpretation: Splits the paper-side chart-level Lorentz receipt from later strengthening receipts. A support-visible Lorentz count means conformal H3 chart plus direct BW/KMS automorphism sanity; a paper-theorem 3D bulk chart count means the simulator has verified the exact chart route Conf+(S2) -> SO+(3,1) -> H3 with boost-orbit dimension 3, rather than fitting a finite point cloud dimension. A support-visible populated-H3 count means persistent record-family support profiles populate that H3 chart under S2-boundary and shuffled-cap controls. Defect-cluster support in H3 is reported separately as a matter/particle precursor. a theorem-assisted object-preview count means the Lorentz chart, BW automorphism sanity, intermediate H3 response control separation, and localized observer-object H3 preview are all present. A nonboundary population count is stricter and requires the boundary leakage audit to pass. Both remain separate from the strict finite endogenous-generator bulk proof and from particles/physical cosmology. The bulk-proof certificate counts make this split explicit: chart-level 3+1D, theorem-assisted H3 preview, nonboundary H3 population, strict neutral bulk, screen-CMB proxy, physical CMB, and production particles are separate gates.

## State-Derived BW Matrix Elements

- runs with state-derived BW reports: 0
- endogenous-generator runs: 0
- declared cap-flow generator runs: 0
- declared response-density runs: 0
- direct transition-automorphism runs: 0
- BW/KMS receipts: 0
- density-log calibration receipts: 0
- endogenous correct-beats-controls count: 0
- selected-2pi count: 0
- state-mode counts: {}
- generator-scale counts: {}
- best-control counts: {}
- target-scale degenerate-control runs: 0
- degenerate target-scale control counts: {}
- generator-scale audit runs: 0
- generator audit configured-best count: 0
- generator audit 2pi-best count: 0
- generator audit best-label counts: {}
- generator audit diagnosis counts: {}
- mean generator-audit best score: n/a
- mean generator-audit configured score: n/a
- mean median residual: n/a
- mean endogenous median residual: n/a
- mean declared cap-flow median residual: n/a
- mean declared response-density median residual: n/a
- mean direct transition median residual: n/a
- mean wrong-1x median: n/a
- mean wrong-pi median: n/a
- mean no-modular-flow median: n/a
- interpretation: No state-derived BW matrix-element reports were found in the selected run set.

## Declared Shape Substrate Witness

- Shape reports: 0
- vertex-scattering receipts: 0
- dodeca cell receipts: 0
- settling receipts: 0
- loop-particle receipts: 0
- screen-projection receipts: 0
- selector-elimination target input receipts: 0
- CMB-certificate input receipts: 0
- declared-3D-substrate reports: 0
- neutral OPH bulk claims: 0
- physical-CMB prediction claims: 0
- mean q_IR target: n/a
- mean q_IR runtime zero-mode: n/a
- mean ell_IR target: n/a
- mean ell_IR runtime covariance rank: n/a
- mean Phi drop fraction: n/a
- mean loop-particle count: n/a
- mean Planck-lite shape correlation: n/a
- mean Planck-lite RMSE: n/a
- interpretation: This lane tests declared dodecahedral three-way scattering, loop modes, loop particles, screen-projection diagnostics, and selector-elimination target inputs such as q_IR=1/4 and ell_IR=32. It is useful as a controlled substrate witness and C_l diagnostic source, but it must not be counted as neutral OPH bulk emergence or a physical CMB prediction.

## Static Galaxy Proxy

- galaxy proxy reports: 0
- proxy receipts: 0
- runs with external RAR/BTFR/disk data: 0
- RAR lambda-fit count: 0
- BTFR fit count: 0
- disk residual count: 0
- mean declared a0_OPH: n/a
- mean effective a0: n/a
- mean declared lambda_collar: n/a
- mean fitted lambda_collar: n/a
- mean BTFR slope: n/a
- interpretation: Static galaxy lane for OPH RAR/BTFR continuation diagnostics. Current run-bundle outputs are proxy surfaces unless external SPARC/RAR/BTFR rows are supplied, so this is measurement-facing scaffolding rather than a publication-grade galaxy likelihood.

## Static Galaxy Measurement Fit

- external fit reports: 0
- RAR/BTFR receipts: 0
- OPH-CET bridge receipts: 0
- claim-tier counts: {}
- physical-claim fit reports: 0
- physical-CMB claim reports: 0
- bulk-required reports: 0
- mean dataset galaxy count: n/a
- mean measurement galaxy count: n/a
- mean RAR galaxy count: n/a
- mean RAR galaxy support count: n/a
- mean RAR point count: n/a
- mean RAR scatter dex: n/a
- mean BTFR slope: n/a
- mean BTFR predicted slope from RAR fit: n/a
- mean BTFR slope delta: n/a
- mean BTFR intercept delta dex: n/a
- holdout usable reports: 0
- holdout receipts: 0
- mean holdout train/test galaxies: n/a / n/a
- mean holdout train/test points: n/a / n/a
- mean holdout shared a0: n/a
- mean holdout shared lambda_collar: n/a
- mean holdout train log-accel RMSE dex: n/a
- mean holdout test log-accel RMSE dex: n/a
- mean holdout test velocity RMSE km/s: n/a
- mean holdout baryon-only velocity RMSE km/s: n/a
- mean holdout velocity RMSE improvement: n/a
- interpretation: External static-galaxy OPH-CET bridge lane. It calibrates the OPH continuation law on RAR acceleration rows with free a0/lambda_collar and reports the asymptotic BTFR implied by that fit when BTFR rows exist. The optional SPARC mass-model holdout splits by galaxy and fits only shared a0/lambda_collar with fixed M/L assumptions. It is measurement-facing static phenomenology; it does not require the populated-bulk gate and is not a physical CMB/P(k) prediction.

## Minimal Caps-To-H3 Calibration

- calibration reports: 0
- calibration receipts: 0
- mean median reconstruction MSE: n/a
- mean shuffled profile MSE: n/a
- mean S2-boundary profile MSE: n/a
- H3 beats shuffled count: 0
- H3 beats S2-boundary count: 0
- claim boundary: S2 cap-profile to H3 geometry calibration only; not a dynamics or populated-bulk claim.

## H3 Seed Ensemble Robustness

- ensemble reports: 0
- response seed-robust receipts: 0
- chart-3D seed-robust receipts: 0
- mean seed count: n/a
- mean single-seed receipt fraction: n/a
- mean control-separation fraction: n/a
- mean candidate receipt fraction: n/a
- mean 3D-window fraction: n/a
- mean heldout normalized RMSE: n/a
- mean heldout explained variance: n/a
- mean p75 material wrong-scale fraction: n/a
- interpretation: Cached H3 seed-ensemble robustness. This prevents accepting a single lucky H3 candidate sample as bulk evidence. The response ensemble receipt uses aggregate control separation, median explained variance, and p75 material wrong-scale fraction; per-seed candidate receipts remain diagnostic because their single-seed gate is stricter. This is still not a populated bulk receipt.

## H3 Modular-Response Receipt

- runs with H3 fits: 0
- H3 receipts: 0
- H3 control-separation precursor receipts: 0
- mean H3 RMSE: n/a
- mean H3 explained variance: n/a
- H3 channel modes: {}
- H3 profile modes: {}
- mean H3 channel count: n/a
- H3-chart 3D-window count: 0
- H3-chart estimator-agreement count: 0
- staged signal gate count: 0
- staged geometry gate count: 0
- staged aggregate wrong-scale gate count: 0
- staged material feature gate count: 0
- mean H3-chart correlation dimension: n/a
- mean H3-chart local-MLE dimension: n/a
- mean S2-boundary RMSE: n/a
- mean shuffled-response RMSE: n/a
- strict wrong-scale feature audits: 0
- mean wrong-scale feature win fraction: n/a
- mean 2pi/H3 feature win fraction: n/a
- wrong-scale red-flag runs: 0
- mean material wrong-scale win fraction: n/a
- mean material 2pi/H3 win fraction: n/a
- material wrong-scale red-flag runs: 0
- worst wrong-scale group sample: n/a

## Observer Readout Consensus

- runs with observer readout reports: 0
- mean observer count: n/a
- mean overlap pair count: n/a
- mean global committed fraction: n/a
- mean median overlap Jaccard: n/a
- mean median signature similarity: n/a
- mean p10 signature similarity: n/a
- mean object overlap agreement: n/a
- mean object p10 overlap agreement: n/a
- mean counterfactual stability: n/a
- bad record rewrite detections: 0

## Observer-Chart Object Population

- runs with object-chart reports: 1
- object-chart receipts: 1
- object-chart median receipts: 1
- object-chart H3 control-separation receipts: 1
- localized-object precursor receipts: 1
- bulk-population receipts: 1
- mean object count: 47
- mean localized object count: 46
- mean localized non-boundary object count: 46
- mean shuffle control count: 16
- mean shuffled localized object count: 38
- mean shuffled localized object p90: 43
- mean H3 compactness: 0.1212151409
- mean S2-boundary compactness: 0.3990423701
- mean shuffled-H3 compactness: 0.1369075339
- mean p10 shuffled-H3 compactness: 0.1319238846
- mean p90 shuffled-H3 compactness: 0.1564091795
- mean H3 margin vs median shuffle: 0.1146203759
- mean H3 margin vs p10 shuffle: 0.08117365318
- mean H3 margin vs S2 boundary: 0.6962349113
- H3 beats median shuffle count: 1
- H3 beats robust shuffle count: 1
- compactness-distribution control receipts: 1
- compactness-distribution strict population receipts: 1
- localized-count saturation warnings: 0
- localized non-boundary saturation warnings: 0

## Neutral Observer Reconstruction

- runs with neutral reconstruction reports: 1
- legacy neutral reconstruction reports: 1
- strict-neutral reports: 0
- strict-neutral bulk receipts: 0
- strict-neutral H3 selected count: 0
- strict-neutral H3 best count: 0
- strict-neutral estimators-agree-3D count: 0
- strict-neutral S2-leakage-pass count: 0
- mean strict-neutral observer count: n/a
- mean strict-neutral median dimension: n/a
- mean strict-neutral correlation dimension: n/a
- mean strict-neutral local-MLE dimension: n/a
- mean strict-neutral S2-distance correlation: n/a
- radial-depth-used count: 0
- control-gate passed count: 1
- candidate 3D-window count: 0
- bulk-established count: 0
- estimators-agree count: 1
- mean primary dimension: 2.373829634
- mean correlation dimension: 2.373829634
- mean local-MLE dimension: 2.667491913
- blind usable count: 1
- blind S2-leakage-pass count: 1
- blind candidate 3D-window count: 0
- blind low-rank usable count: 1
- blind low-rank selected 3D-candidate count: 0
- blind low-rank selected 3D-window count: 0
- blind low-rank selected S2-leakage-pass count: 1
- blind record-transition rank-3 receipt count: 1
- blind record-transition rank-3 3D-window count: 1
- blind record-transition rank-3 estimator-agreement count: 1
- blind record-transition rank-3 S2-leakage-pass count: 1
- blind bulk-established count: 0
- mean blind feature width: 55
- mean blind S2-distance correlation: 0.0731900157
- mean blind correlation dimension: 7.866539312
- mean blind local-MLE dimension: 11.80838958
- mean blind low-rank participation rank: 9.936915991
- mean blind low-rank entropy rank: 16.21590045
- mean blind low-rank selected rank: 8
- mean blind low-rank selected correlation dimension: 5.547227534
- mean blind low-rank selected local-MLE dimension: 6.423965673
- mean blind low-rank selected S2-distance correlation: 0.054284838
- mean blind record-transition rank-3 correlation dimension: 2.701366591
- mean blind record-transition rank-3 local-MLE dimension: 2.945863255
- mean blind record-transition rank-3 S2-distance correlation: 0.002537951638

## Planck-Lite Screen C_l Shape

- runs with CMB-lite comparisons: 1
- best-field counts: {'scale_compressed_repair': 1}
- best-positive-field counts: {'scale_compressed_repair': 1}
- best real-ell overlap field counts: {'scale_compressed_repair': 1}
- mean best-field correlation: 0.8039372295
- mean best-field RMSE: 0.5947141591
- mean best-positive-field correlation: 0.8039372295
- mean best-positive-field RMSE: 0.5947141591
- mean record-signature correlation: n/a
- mean record-signature RMSE: n/a
- real-ell overlap usable runs: 0
- mean record-signature overlap-ell correlation: n/a
- mean record-signature overlap-ell RMSE: n/a
- mean overlap ell range: [n/a, n/a]
- mean overlap benchmark bins: n/a
- best real-ell overlap usable runs: 1
- mean best real-ell overlap correlation: 0.8001490536
- mean best real-ell overlap RMSE: 0.5998012105
- mean best real-ell overlap range: [47.711224, 2499.024]
- mean best real-ell overlap benchmark bins: 83

## Finite-Screen CMB Anomaly Readouts

- anomaly reports: 1
- primary-field counts: {'record_signature': 1}
- best low-power field counts: {'s3_class_density': 1}
- best large-angle field counts: {'s3_class_density': 1}
- best parity field counts: {'record_signature_smooth_k32': 1}
- best tilt field counts: {'record_signature_smooth_k32': 1}
- mean best low-power fraction: 0.2238123673
- mean best S1/2 scalar proxy: 6.638603898e-09
- mean best parity log deviation: 6.079209956
- mean best eta_R: -0.2886922358
- mean best n_s proxy: 1.288692236
- mean low-power-suppressed field count: 0
- mean large-angle-suppressed field count: 0
- mean parity-asymmetric field count: 8
- mean Planck-tilt-compatible field count: 0
- mean total entropy capacity: 106887.1326
- mean sqrt-N ell capacity proxy: 511
- physical-CMB prediction reports: 0
- interpretation: Finite-screen anomaly readout from actual C_l receipts. It targets the OPH CMB bridge questions about scale tilt, low multipoles, odd/even parity, large-angle correlations, and finite screen capacity. It is screen-only: no photon-baryon transfer, no official Planck likelihood, and no 3D-bulk proof.

## CMB Screen-Basis Transfer

- transfer reports: 0
- diagnostic receipts: 0
- mean train correlation: n/a
- mean train RMSE: n/a
- mean test correlation: n/a
- mean test RMSE: n/a
- mean max control test correlation: n/a
- mean test-control correlation gap: n/a
- mean bootstrap test correlation [p05, p95]: [n/a, n/a]
- mean bootstrap test RMSE [p05, p95]: [n/a, n/a]
- interpretation: Cross-scale screen-basis transfer is the strongest current Planck-facing diagnostic. It fits weights using observed Planck TT shape and checks transfer across patch counts against target/field-shuffle controls, so it is useful evidence about screen-statistic structure but not a physical CMB prediction.

## CAMB LambdaCDM Baseline

- baseline reports: 0
- CDM-limit Boltzmann receipts: 0
- OPH anomaly-module-ready reports: 0
- mean shape correlation: n/a
- mean normalized RMSE: n/a
- mean amplitude-fit chi2/bin: n/a
- mean best-fit-column chi2/bin: n/a
- mean first peak ell: n/a
- mean benchmark first peak ell: n/a
- mean absolute fractional error: n/a
- interpretation: External LambdaCDM CAMB baseline for CDM-limit/Boltzmann plumbing. This lane should match the local Planck TT benchmark reasonably well and gives us a regression target for any future OPH anomaly module. It is not an OPH prediction because all cosmological parameters are external defaults and no repair/anomaly source term is injected.

## OPH Screen-Power Effective Theory

- screen-power reports: 1
- simulator primordial-ready reports: 0
- physical-CMB prediction reports: 0
- mean source run count: 0
- mean fit row count: 0
- mean available fit count: 0
- best Planck-eta field counts: {}
- reference-source counts: {'paper_maxent_green_spectrum_plus_selector_elimination_not_finite_lattice': 1}
- mean reference eta_R: 0.03515885697
- mean reference n_s: 0.964841143
- mean simulator record-signature eta_R: n/a
- mean simulator stable-count eta_R: n/a
- interpretation: OPH screen-power effective-theory bridge. This is where finite screen C_l fields are converted into eta_R/n_s and a primordial-table scaffold. If simulator_primordial_ready_count is zero, the exported reference table is either a phenomenological Planck-target fallback or a deliberately labeled failed finite diagnostic, not a simulator-ready primordial prediction.

## OPH Screen CAMB Transfer

- OPH-screen CAMB reports: 0
- transfer receipts: 0
- simulator eta-ready reports: 0
- physical-CMB prediction reports: 0
- reference-source counts: {}
- mean eta_R: n/a
- mean n_s: n/a
- mean shape correlation: n/a
- mean normalized RMSE: n/a
- mean amplitude-fit chi2/bin: n/a
- mean first peak ell: n/a
- mean benchmark first peak ell: n/a
- mean absolute fractional error: n/a
- interpretation: CAMB TT transfer from the OPH screen-power scalar scaffold. A transfer receipt means CAMB plumbing and Planck TT comparison are working. It is a physical OPH prediction only when the input screen report is simulator-derived, passes the simulator_eta_ready/readiness gates, and the downstream finite-certificate gates pass.

## OPH MaxEnt Green-Spectrum Source

- source reports: 1
- source receipts: 1
- flat-Green receipts: 1
- IR theorem receipts: 1
- source-packet audits: 1
- repair-clock certificates: 0
- bandlimit-for-IR counts: 1
- bandlimit-for-requested-ell counts: 1
- finite-lattice-derived reports: 0
- physical-CMB prediction reports: 0
- mean eta_R: 0.03515885697
- mean n_s: 0.964841143
- mean q_IR: 0.25
- mean ell_IR: 32
- mean N_frz proxy: 1089
- mean F_IR(ell=2): 0.7514164268
- mean F_IR(ell=32): 0.9080301397
- interpretation: Paper-side finite-screen CMB source certificate. This lane verifies the MaxEnt inverse-Laplacian screen covariance, selector-eliminated q_IR/ell_IR target, and a CAMB/CLASS primordial-table scaffold. The finite repair-clock certificate kappa_rep=e, finite freezeout emission, parity/BipoSH covariance, and official likelihood gates remain separate.

## OPH Repair-Clock Kappa Audit

- repair-clock reports: 1
- finite repair-clock certificates: 0
- eta_R finite-lattice-derived reports: 0
- cycle-time normalization declared reports: 0
- mean candidate run count: 4
- mean estimator count: 4
- mean eligible estimator count: 0
- mean passed estimator count: 0
- mean median kappa_rep estimate: 16.91187547
- target kappa_rep: 2.718281828
- mean median eta_R estimate: 0.218741929
- target eta_R: 0.03515885697
- mean blocker count: 2
- interpretation: Finite repair-clock audit for the exact OPH CMB scalar tilt eta_R=kappa_rep*(P-phi). This is the remaining dynamic certificate after q_IR and ell_IR selector elimination. Diagnostic trace fits are kept visible, but the lane does not certify a physical CMB prediction unless theorem-grade eligible rows derive kappa_rep=e under declared controls.

## OPH Scalar Repair-Semigroup Gap

- semigroup reports: 1
- algebraic target receipts: 0
- repair-clock certificates: 0
- eligible certificate reports: 0
- finite-lattice-derived reports: 1
- sources: ['finite_state_transition_matrix']
- mean dimension: 2
- mean centered dimension: 1
- mean kappa_rep: 2.592344557
- mean eta_R: 0.03352995651
- mean n_s: 0.9664700435
- mean centered gap: 0.03352995651
- mean primary lambda_2: 0.2
- mean required repair-step time for kappa=e: 45.77617281
- transition clock certified reports: 0
- controls-passed reports: 1
- interpretation: Scalar repair-semigroup gap lane for the exact OPH CMB clock. A declared Euler target only checks the algebraic route to kappa_rep=e. A finite support-visible transition matrix is stronger, but it still certifies the CMB clock only if its declared repair-step normalization yields kappa_rep=e under the report controls.

## OPH Inflation/CMB Bridge

- bridge reports: 0
- v0.4 public-data diagnostic reports: 0
- physical-CMB prediction reports: 0
- mean n_s = 1 - P/48: n/a
- mean theta_OPH = P/48: n/a
- mean A_zeta: n/a
- mean n_s pull vs Planck target: n/a
- mean selected Omega_K: n/a
- mean residual Omega_A0: n/a
- mean rho_A/rho_b: n/a
- mean OPH IR q_IR: n/a
- mean OPH IR ell_IR: n/a
- mean CAMB LCDM low-ell chi2: n/a
- mean CAMB OPH-IR low-ell chi2: n/a
- mean LCDM R_OE upper-tail PTE: n/a
- mean OPH parity R_OE upper-tail PTE: n/a
- v0.5 TT low-ell delta chi2: n/a
- v0.5 TE low-ell delta chi2: n/a
- v0.5 EE low-ell delta chi2: n/a
- v0.5 TT high-ell delta chi2, ell=30..1200: n/a
- v0.5 combined TT+TE+EE low-ell delta chi2: n/a
- v0.5 pressure/not-yet-run gate count: n/a
- interpretation: Continuation bridge imported from the Pro CMB/inflation notes. It supplies P/48 screen-spectrum numbers, zero-holonomy flat-sector bookkeeping, and measured Planck low-ell/CAMB diagnostic ladders including v0.5 TT/TE/EE hard-gate proxies. It is not a finite-lattice derivation of those numbers and not an official Planck likelihood.

## OPH Inflation Certificate Stack

- certificate reports: 0
- stack-ready reports: 0
- physical-CMB prediction reports: 0
- physical matter-power prediction reports: 0
- no-data-use firewall count: 0
- scalar/edge/anomaly/parent/repair/boltzmann gates: 0 / 0 / 0 / 0 / 0 / 0
- mean found/passed/expected certificates: n/a / n/a / n/a
- mean missing certificate count: n/a
- mean A_zeta: n/a
- mean n_s: n/a
- mean Q_A: n/a
- mean B_A: n/a
- mean Gamma_rec: n/a
- interpretation: Finite certificate stack for the inflation-free OPH cosmology branch. This lane is the artifact contract for A_zeta, n_s, Q_A, B_A(k,a), Gamma_rec(k,a), and Boltzmann handoff. The current report is a physical prediction only when all finite certificates and the no-data-use firewall pass before likelihood comparison.

## OPH Finite Certificate Authority

- finite certificate bundles: 0
- compiler-ready bundles: 0
- legacy stack-ready bundles: 0
- theorem-grade finite-input bundles: 0
- proxy-certificate bundles: 0
- no-data-use receipts: 0
- release-code gates: 0
- parent-collar gates: 0
- repair-matrix gates: 0
- Boltzmann-export gates: 0
- real-physics certificate bundles: 0
- physical-CMB prediction reports: 0
- mean A_zeta: n/a
- mean n_s: n/a
- mean Q_A: n/a
- mean B_A: n/a
- mean Gamma_rec: n/a
- interpretation: Finite OPH cosmology certificate authority. This lane computes A_zeta, Q_A, B_A(k,a), Gamma_rec, and a Boltzmann handoff contract from finite release/collar/repair inputs. Compiler-ready means certificate artifacts are internally consistent, not theorem-grade. Toy/proxy inputs validate the compiler only; physical CMB and matter-power gates remain closed until real simulator regulator data and cold-limit solver receipts pass the firewall.

## OPH Scalar Geometric Quotient

- scalar quotient reports: 0
- scalar quotient receipts: 0
- finite-ready scalar releases: 0
- active 33-level clauses: 0
- theorem-grade release codes: 0
- physical-CMB prediction reports: 0
- mean n_s: n/a
- mean observer level proxy: n/a
- mean patch capacity level proxy: n/a
- interpretation: Finite observer-visible scalar/geometric quotient lane. This is the direct instrumentation needed before CMB promotion: scalar packets, center-free scalar screen fields, P/48 readout, and the 33-level freezeout clause are audited separately. A scalar quotient receipt is not a physical CMB prediction unless finite-ready, theorem-grade release, parent-collar, repair, and likelihood gates also pass.

## Neutral Distance Profile Audit

- profile audit reports: 0
- strict-ready profile count: 0
- all-profile best models: {}
- scalar-response best models: {}
- prime-geometric best models: {}
- prime control-quotient best models: {}
- prime rank-3 best models: {}
- prime rank-8 best models: {}
- prime control-quotient rank-3 best models: {}
- prime control-quotient rank-8 best models: {}
- support-visible best models: {}
- mean all-profile corr/local-MLE dimension: n/a / n/a
- mean all-profile S2 leakage corr: n/a
- mean scalar-response corr/local-MLE dimension: n/a / n/a
- mean scalar-response S2 leakage corr: n/a
- mean prime-geometric corr/local-MLE dimension: n/a / n/a
- mean prime-geometric S2 leakage corr: n/a
- mean prime control-quotient corr/local-MLE dimension: n/a / n/a
- mean prime control-quotient S2 leakage corr: n/a
- mean prime rank-3 corr/local-MLE dimension: n/a / n/a
- mean prime rank-3 S2 leakage corr: n/a
- mean prime control-quotient rank-3 corr/local-MLE dimension: n/a / n/a
- mean prime control-quotient rank-3 S2 leakage corr: n/a
- mean prime rank-8 corr/local-MLE dimension: n/a / n/a
- mean prime rank-8 S2 leakage corr: n/a
- mean prime control-quotient rank-8 corr/local-MLE dimension: n/a / n/a
- mean prime control-quotient rank-8 S2 leakage corr: n/a
- mean support-visible corr/local-MLE dimension: n/a / n/a
- mean support-visible S2 leakage corr: n/a
- interpretation: Bounded diagnostic over neutral-distance feature profiles. It identifies whether the observer-visible packet is overcomplete, undercomplete, or still screen-leaky. It does not establish strict neutral 3D bulk.

## Prime-Geometric Rank Sweep

- rank-sweep reports: 5
- quotient 3D diagnostic receipts: 5
- spatial 3D candidate receipts: 0
- control-quotient spatial 3D candidate receipts: 5
- strict neutral candidate receipts: 0
- selected-rank controls written: 5
- selected-rank controls all failed: 5
- coordinate rank-3 tautology warnings: 5
- selected directional control survive/fail counts: 0 / 15
- selected coordinate control survive/fail counts: 15 / 0
- strict-ready ranks: 0
- dimension-window ranks: 7
- best-rank counts: {'8': 1, '10': 4}
- best-model counts: {'H4': 5}
- mean best-rank corr/local-MLE dimension: 3.051679975 / 2.990404534
- mean best-rank S2 leakage corr: 0.3193932916
- best 3D-window ranks: {'8': 1, '10': 4}
- best 3D-window models: {'H4': 5}
- mean best 3D-window corr/local-MLE dimension: 3.051679975 / 2.990404534
- coordinate spatial-3D-ready ranks: 0
- coordinate dimension-window ranks: 5
- coordinate best-rank counts: {'3': 5}
- coordinate best-model counts: {'E3': 5}
- coordinate mean best-rank corr/local-MLE dimension: 2.726793751 / 3.033104094
- coordinate mean best-rank S2 leakage corr: 0.140602882
- coordinate best 3D-window ranks: {'3': 5}
- coordinate best 3D-window models: {'E3': 5}
- coordinate mean best 3D-window corr/local-MLE dimension: 2.726793751 / 3.033104094
- control quotient marked as negative control: {'False': 5}
- control-quotient strict-ready ranks: 0
- control-quotient dimension-window ranks: 5
- control-quotient best-rank counts: {'8': 5}
- control-quotient best-model counts: {'H4': 5}
- control-quotient mean best-rank corr/local-MLE dimension: 2.852424633 / 2.861132178
- control-quotient mean best-rank S2 leakage corr: -0.004724937226
- control-quotient coordinate spatial-3D-ready ranks: 5
- control-quotient coordinate dimension-window ranks: 5
- control-quotient coordinate best-rank counts: {'3': 5}
- control-quotient coordinate best-model counts: {'E3': 5}
- control-quotient coordinate mean best-rank corr/local-MLE dimension: 2.663077211 / 2.999755512
- control-quotient coordinate mean best-rank S2 leakage corr: 0.00677020015
- control-quotient coordinate best 3D-window ranks: {'3': 5}
- control-quotient coordinate best 3D-window models: {'E3': 5}
- control-quotient coordinate mean best 3D-window corr/local-MLE dimension: 2.663077211 / 2.999755512
- control-quotient coordinate mean best 3D-window S2 leakage corr: 0.00677020015
- control-quotient coordinate best 3D-window S2 leakage-pass count: 5
- interpretation: Diagnostic low-rank quotient sweep over prime-geometric modular response and its finite-regulator control quotient. Directional/cosine rows test angular response structure; coordinate rows test whether response coordinates already carry a neutral 3D spatial chart. The control quotient is a target-response quotient with regulator-control directions removed, not a shuffled/null negative control. These are diagnostics only until controls and refinement pass.

## Prime-Geometric Rank Refinement

- refinement reports: 1
- source run count mean: 4
- multi-scale reports: 1
- rank-3 refinement candidate receipts: 1
- strict neutral refinement receipts: 0
- all-candidate reports: 1
- all-candidate S2-leakage-pass reports: 1
- all-candidate rank-3/E3 reports: 1
- dimension-stable reports: 1
- independent rank-3 selector reports: 0
- mean/max candidate dimension drift: 0.02765758436 / 0.02765758436
- patch-count sets: {'[65536, 262144]': 1}
- size median dimension sets: {'[2.8435291556015314, 2.815871571245574]': 1}
- blocker counts: {'independent_svd_rank3_selector_not_stable_or_false': 1, 'control_quotient_lane_is_not_a_negative_control': 1, 'directional_h3_strict_rank_gate_not_passed': 1}
- interpretation: Cross-regulator diagnostic for the control-quotient coordinate rank-3 window. A candidate receipt means the supplied rank-3/E3 control-quotient window is stable across patch counts and passes the S2-leakage gate. It is not a strict neutral 3D-bulk proof because the independent SVD rank selector, proper negative-control replacement, and directional H3 strict gates remain separate blockers.

## OPH Parent-Collar Recovery Ladder

- parent-collar ladder reports: 1
- compiler-ready reports: 1
- regulator-ladder-ready reports: 1
- scaling-pass reports: 0
- local recovery-density reports: 1
- strict local recovery-density reports: 0
- theorem-grade reports: 0
- strict cap-family reports: 0
- unique theta-family reports: 1
- physical-CMB prediction reports: 0
- mean collar report count: 9
- mean cap-row count: 68
- mean regulator patch-count count: 3
- mean log p90-CMI vs log-N slope: 0.3521384724
- mean log p90-CMI/collar vs log-N slope: -0.1499774038
- mean final p90 epsilon_CMI: 1.928689477
- mean final p90 epsilon_CMI/collar: 0.001062237532
- mean final p90 r_FR: 2.776474572
- interpretation: Finite parent-collar recovery ladder diagnostic. This aggregates cached diagonal collar-Markov CMI/Fawzi-Renner proxy reports across regulator sizes. It is the right input lane for future finite CMB certificates, but it is not theorem-grade unless the recovery errors improve with refinement and pass conservative cold-limit thresholds.

## OPH B_A Parent Finite Difference

- B_A parent reports: 1
- B_A parent receipts: 0
- paired finite diagnostic receipts: 1
- physical-prediction-ready reports: 0
- physical-CMB prediction reports: 0
- controls-fail reports: 1
- real baryon perturbation rerun reports: 1
- finite observer-view parent variation reports: 0
- refinement convergence reports: 0
- primary parent source counts: {'paired_cap_collar_perturb_resettle_rerun': 1}
- mean source report count: 0
- mean observer-view source count: 0
- mean B_A rows: 32
- mean B_A control rows: 192
- control failure counts: {'no_perturbation': 1, 'no_repair_load_channel': 1, 'baryon_delta_applied_after_record_freezeout': 1, 'phase_shuffled_baryon_mode': 1, 'random_collar_labels': 1, 'wrong_k_label': 1}
- missing gate counts: {'scale_calibrated_k_h_mpc': 1, 'calibrated_a_evolution': 1, 'rho_A_of_a_physical_emitted': 1, 'rho_A_eq_of_a_physical_emitted': 1, 'Gamma_rec_of_k_a_emitted': 1, 'energy_momentum_exchange_closed': 1, 'gauge_consistency_audited': 1, 'refinement_convergence_passed': 1}
- interpretation: Finite-difference B_A(k,a) parent diagnostic from observer-visible cap/collar packet variation. The paired diagnostic receipt means real plus/minus perturb-resettle reruns, sign stability, and expected control failures are present. It is still not a physical Boltzmann kernel unless k/a units are calibrated, energy exchange is closed, and refinement passes.

## OPH Screen-Capacity Closure

- screen-capacity reports: 1
- observed-branch readout reports: 1
- F(N) implemented reports: 0
- finite-simulator fixed-point solved reports: 0
- physical-CMB prediction reports: 0
- input-mode counts: {'observed_de_sitter_radius_readout': 1}
- mean N_patch bare ratio: 1.055196794e+122
- mean N_scr entropy capacity: 3.314998497e+122
- mean Lambda l_P^2: 2.843071563e-122
- mean local P-cell count for N_scr: 8.13013639e+122
- interpretation: Global cosmic record/screen-capacity closure lane. It gives the observed-branch de Sitter entropy-capacity normalization and Lambda*l_P^2 readout, while keeping ordinary finite patch counts as numerical regulators until the OPH readback map F(N) is implemented.

## OPH Repair-Scale Closure

- repair-scale reports: 1
- numeric match within 1% reports: 1
- declared 24-round reports: 1
- finite-selector-derived 24-round reports: 0
- finite-lattice-derived eta_R reports: 0
- physical-CMB prediction reports: 0
- populated-3D-bulk reports: 0
- mean |g'(P)|: 0.002787340652
- mean q per round: 358.7649035
- mean predicted N_CRC from P: 4.274424587e+122
- mean declared N_CRC: 3.314998497e+122
- mean n_s = 1-P/48: 0.9660214956
- mean 1M effective repair-round depth: 1.178287236
- interpretation: Maarten/OPH 24-round scale-closure hypothesis. This lane predicts a local repair contraction |g'(P)|=alpha/phi^2, an implied N_CRC=|g'|^-48, and n_s=1-P/48. It explains finite-regulator shallow depth, but does not derive the 24 rounds from a finite selector and does not establish populated 3D bulk or physical CMB.

## OPH Scale-Compressed Repair Branch

- compressed branch reports: 1
- operator receipts: 1
- round-trace receipts: 1
- cap-profile H3 receipts: 1
- populated-H3 preview reports: 1
- strict neutral bulk reports: 0
- particle preview reports: 1
- production particle-matter reports: 0
- physical-CMB prediction reports: 0
- mean rounds: 24
- mean eta_R: 0.03397850436
- mean n_s: 0.9660214956
- mean q_IR: 0.25
- mean ell_IR: 32
- mean object count: 2048
- mean particle worldline count: 128
- interpretation: Logical 24-round scale-compressed repair branch. This lane makes the repair-depth hypothesis computable now: it emits a round trace, OPH CMB scalar parameters, a screen C_l scaffold, and a populated H3 preview. It is not a literal finite-patch proof, not strict neutral bulk, and not a physical CMB prediction.

## OPH Scale-Compressed CMB CAMB Transfer

- CAMB transfer reports: 1
- measurement-comparable curve reports: 1
- transfer receipts: 1
- operator receipts: 1
- H3 preview receipts: 1
- physical-CMB prediction reports: 0
- mean rounds: 24
- mean eta_R: 0.03397850436
- mean n_s: 0.9660214956
- mean q_IR: 0.25
- mean ell_IR: 32
- mean LCDM shape correlation: 0.9998604572
- mean scale-compressed scalar shape correlation: 0.9998574617
- mean scale-compressed IR shape correlation: 0.9998534543
- mean LCDM chi2/bin: 0.9444957497
- mean scale-compressed scalar chi2/bin: 0.954498157
- mean scale-compressed IR chi2/bin: 0.9615050793
- mean acoustic |delta|: 0.001358594647
- interpretation: CAMB TT transfer for the logical 24-round scale-compressed repair branch. This is the current closest measurement-comparable CMB artifact tied to the repair-depth simulator readouts. It remains non-physical until the 24-round selector, amplitude, anomaly-sector, and official likelihood/map-space gates are closed.

## OPH Inflation/CMB CAMB Transfer

- CAMB transfer reports: 0
- measurement-comparable curve reports: 0
- transfer receipts: 0
- physical-CMB prediction reports: 0
- mean n_s: n/a
- mean A_zeta: n/a
- mean q_IR: n/a
- mean ell_IR: n/a
- mean LCDM high-ell shape correlation: n/a
- mean OPH P/48 high-ell shape correlation: n/a
- mean OPH P/48+IR high-ell shape correlation: n/a
- mean LCDM high-ell chi2/bin: n/a
- mean OPH P/48 high-ell chi2/bin: n/a
- mean OPH P/48+IR high-ell chi2/bin: n/a
- mean acoustic |delta|: n/a
- imported low-ell LCDM chi2: n/a
- imported low-ell OPH-IR chi2: n/a
- mean unique v0.9 n_s: n/a
- mean unique v0.9 q_IR: n/a
- mean unique v0.9 ell_IR: n/a
- mean unique v0.9 high-ell shape correlation: n/a
- mean unique v0.9 chi2/bin: n/a
- mean unique v0.9 acoustic |delta|: n/a
- interpretation: Direct CAMB TT transfer for the OPH P/48 screen spectrum plus imported v0.4 IR kernel. This lane emits an actual CMB curve and compares it with the local Planck TT benchmark table. It remains a continuation diagnostic until the finite lattice derives A_zeta, q_IR, ell_IR, and angular covariance from cap/collar microphysics.

## OPH CMB Selector Elimination v1.5

- selector-elimination reports: 1
- theorem-side receipts: 1
- source-packet audit receipts: 1
- q_IR selector-removed count: 1
- ell_IR selector-removed count: 1
- eta_R repair-clock reduction count: 1
- finite-lattice-derived reports: 0
- physical-CMB prediction reports: 0
- exact-kernel CSV pass count: 1
- mean exact-kernel CSV max error: 0
- mean n_s: 0.964841143
- mean eta_R: 0.03515885697
- mean q_IR: 0.25
- mean ell_IR: 32
- kappa_rep status counts: {'certificate_pending': 1}
- interpretation: v1.5 OPH-CMB selector-elimination lane. q_IR and ell_IR are counted as theorem-side target derivations when their receipts pass; eta_R is only reduced to a repair-clock certificate until the finite lattice derives kappa_rep=e. This lane strengthens the exact target branch but does not by itself make the CAMB curve a physical finite-lattice CMB prediction.

## OPH Exact CMB CAMB Transfer

- CAMB transfer reports: 0
- measurement-comparable curve reports: 0
- transfer receipts: 0
- physical-CMB prediction reports: 0
- official clik-ready reports: 0
- official likelihood-ready reports: 0
- embedded selector theorem receipts: 0
- embedded selector source-audit receipts: 0
- mean exact n_s: n/a
- mean exact eta_R: n/a
- mean exact q_IR: n/a
- mean exact ell_IR: n/a
- mean exact N_frz proxy: n/a
- mean LCDM shape correlation: n/a
- mean exact scalar shape correlation: n/a
- mean exact IR shape correlation: n/a
- mean LCDM chi2/bin: n/a
- mean exact scalar chi2/bin: n/a
- mean exact IR chi2/bin: n/a
- mean acoustic |delta|: n/a
- interpretation: Native CAMB TT transfer for the exact OPH CMB target branch updated with the v1.5 selector-elimination receipts: q_IR and ell_IR are theorem-side target counts, while n_s still depends on the pending kappa_rep=e repair-clock certificate. This is measurement-comparable Boltzmann output, but remains a target/continuation diagnostic until finite lattice derivation and official Planck likelihood/map-space gates pass.

## Finite Repair-Clock CMB CAMB Transfer

- CAMB transfer reports: 1
- measurement-comparable curve reports: 1
- transfer receipts: 1
- finite-lattice clock reports: 1
- exact repair-clock certificate reports: 0
- selector IR theory-side reports: 1
- physical-CMB prediction reports: 0
- mean finite-clock n_s: 0.9679812501
- mean finite-clock eta_R: 0.03201874992
- mean finite-clock kappa_rep: 2.475506702
- mean q_IR: 0.25
- mean ell_IR: 32
- mean finite-clock scalar shape correlation: 0.9998504842
- mean finite-clock IR shape correlation: 0.999846292
- mean finite-clock scalar chi2/bin: 0.9836766604
- mean finite-clock IR chi2/bin: 0.9910099836
- mean acoustic |delta|: 0.003714988073
- interpretation: Native CAMB TT transfer using the finite transition-matrix repair clock emitted by the simulator. This is the strongest current simulator-derived CMB curve lane: n_s comes from finite repair data. It remains non-physical until the exact repair-clock certificate, selector finite-register certificate, physical source/k calibration, and official likelihood gates pass.

## OPH Unique Prediction Gate v0.9

- target reports: 0
- measurement-comparable target reports: 0
- finite-lattice-derived target reports: 0
- physical-CMB prediction reports: 0
- mean n_s: n/a
- mean eta_R: n/a
- mean Planck n_s pull: n/a
- mean q_IR: n/a
- mean ell_IR: n/a
- mean N_frz proxy: n/a
- mean parity R_OE TT(2..29): n/a
- mean sum m_nu eV: n/a
- mean neutrino f_nu: n/a
- mean small-scale neutrino suppression: n/a
- interpretation: Current v0.9 OPH-only public-comparison target lane: alpha-linked scalar tilt, exact IR kernel, parity envelope, neutrino mass sum, and compressed dark-sector rows. These are measurement-comparable targets, not finite-lattice derivations unless the derivation audit passes.

## OPH-CnuB Neutrino Background

- neutrino reports: 1
- measurement-comparable reports: 1
- finite-lattice-derived reports: 0
- physical-CMB prediction reports: 0
- physical matter-power prediction reports: 0
- background/mass/B_A/likelihood gate counts: 1 / 0 / 0 / 0
- five-of-seven kernel/projection counts: 1 / 1
- Planck+BAO / ACT / DESI strict sum-mnu pass counts: 1 / 0 / 0
- mean N_eff: 3.044
- mean sum m_nu eV: 0.09001192964
- mean lightest mass eV: 0.01745472026
- mean Omega_nu h2: 0.0009666229558
- mean f_nu: 0.006744316582
- mean small-scale suppression: -0.05395453265
- mean Planck N_eff pull sigma: 0.3176470588
- mean eta_A: 0.06569936051
- mean compressed Pi_WL target: 0.7147300876
- mean five-of-seven Pi_WL: 0.7142857143
- mean five-of-seven epsilon_A: 0.04692811465
- mean five-of-seven projected S8: 0.7900242005
- mean five-of-seven S8 pull sigma: 0.001512529599
- interpretation: Standalone OPH-CnuB relic-neutrino background lane. The weighted-cycle neutrino masses are measurement-comparable through standard relic-neutrino cosmology, while finite-lattice mass derivation, B_A(k,a), and full Boltzmann/likelihood gates remain closed.

## Finite Lattice CMB Derivation Audit

- derivation reports: 0
- ready reports: 0
- mean source run count: n/a
- mean finite eta_R: n/a
- mean eta_R absolute error: n/a
- mean scalar-quotient n_s: n/a
- mean scalar-quotient theta_OPH: n/a
- mean scalar-quotient n_s target error: n/a
- mean finite q_IR: n/a
- mean finite ell_IR: n/a
- mean collar median CMI: n/a
- interpretation: Audit of whether current finite lattice reports derive the CMB target parameters from cap/collar/screen receipts. A ready count of zero means comparable target numbers exist, but the finite simulator has not yet earned a physical CMB prediction claim.

## OPH Boltzmann Input Readouts

- input reports: 1
- CDM-limit-ready reports: 0
- diagnostic repair-table-ready reports: 1
- physical-prediction-ready reports: 0
- mean source report count: 2
- mean CDM row count: 4
- mean diagnostic row count: 32
- mean missing gate count: 9
- mean Gamma_rec/H shape proxy: 0.6385992516
- mean B_A shape proxy: -4.770489559e-18
- interpretation: Machine-readable bridge from OPH-CMB diagnostics to future CAMB/CLASS inputs. The CDM-limit rows are solver-ready only as an external LambdaCDM regression target. The repair-exchange rows are finite-collar proxy shapes and remain gated against physical prediction language.

## Finite-Collar Boltzmann Source Bundle

- source-bundle reports: 1
- diagnostic bundle receipts: 1
- physical export certificates: 0
- physical-CMB prediction reports: 0
- no-data-use reports: 1
- mean B_A rows: 64
- mean rho_A rows: 64
- mean Gamma_rec rows: 4
- mean physical missing gate count: 6
- mean |B_A|: 0.0007672576874
- mean |Gamma_rec/H|: 0.03201874992
- diagnostic missing gate counts: {}
- physical missing gate counts: {'physical_k_units_calibrated': 1, 'calibrated_a_evolution': 1, 'energy_momentum_exchange_closed': 1, 'gauge_consistency_audited': 1, 'refinement_convergence_passed': 1, 'physical_cmb_input_contract_passed': 1}
- interpretation: Consolidated finite-collar source bundle for the OPH Boltzmann/CMB bridge. A diagnostic receipt means rho_A(a), rho_A,eq(a), B_A(k,a), and Gamma_rec(k,a) source-side tables exist behind a no-data firewall. A physical certificate still requires calibrated k/a units, energy-exchange closure, refinement convergence, strict freezeout/bulk gates, CDM-limit regression, and an official likelihood-ready path.

## Finite-Collar CMB Projection

- projection reports: 1
- projection receipts: 1
- physical-k calibration receipts: 0
- physical-CMB prediction reports: 0
- mean projected B_A rows: 64
- mean background rows: 4
- mean ell range: 3.141592654 .. 8.97597901
- mean B_A: -0.0006478176402
- mean |B_A|: 0.0007672576874
- mean B_A positive fraction: 0.25
- mean log |B_A| / log ell slope: 2.866980616
- mean largest-scale B_A: -8.490780381e-05
- mean smallest-scale B_A: -0.001699223125
- interpretation: External-fiducial ell/k projection of finite-collar B_A rows. This is useful for measurement-facing plots and Boltzmann plumbing, but it does not close the physical k calibration gate because chi_* and h are declared comparison geometry rather than derived from the finite OPH screen-to-bulk scale theorem.

## Low-k Synchronization Gap

- gap audit reports: 0
- mean source run count: n/a
- low-k gap established reports: 0
- same-boundary selector reports: 0
- inflation-replacement-ready reports: 0
- mean time-resolved trace count: n/a
- mean cached proxy pass count: n/a
- mean time-resolved gap pass count: n/a
- mean global Phi gamma/cycle: n/a
- interpretation: Low-k synchronization-gap audit for OPH inflation-replacement questions. Cached final spectra and global Phi decay are useful diagnostics. Residual-field candidates report majority-mode repair/mismatch decay, but a true horizon-coherence/gap claim requires the stricter all-mode time-resolved harmonic repair gate and controls.

## Hot MaxEnt Release

- release audit reports: 0
- mean source run count: n/a
- theorem-ready release reports: 0
- mean mechanical release surfaces: n/a
- mean collar-gate passes: n/a
- mean theorem-ready source runs: n/a
- mean median release cycle: n/a
- mean collar median CMI: n/a
- interpretation: Hot-MaxEnt release audit. A mechanical release surface means repair and record commitment settle together; it becomes theorem-ready only when collar Markov/recovery errors and the physical unit/charge map also pass.

## Same-Boundary Adiabaticity

- adiabaticity audit reports: 0
- mean source run count: n/a
- established reports: 0
- mean proxy pass count: n/a
- mean max entropy residual std: n/a
- mean min common-clock correlation: n/a
- interpretation: Same-boundary adiabaticity/isocurvature proxy. Current channels are observer-visible record fields, not physical photon/baryon/neutrino fluids, so this lane remains a gate audit until the Boltzmann species map exists.

## H0/S8 Branch Diagnostic

- H0/S8 reports: 1
- physical-prediction-ready reports: 0
- Q_A/B_A/Gamma_J gate counts: 0 / 0 / 0
- lambda(P) gate count: 1
- CAMB/CLASS and likelihood gate counts: 0 / 0
- Lane-8 certificate / run-derived / ready counts: 1 / 0 / 0
- Lane-8 payload/fake/selector/refinement gate counts: 1 / 0 / 1 / 1
- mean H0 km/s/Mpc: 67.40002854
- mean Omega_m: 0.3154851573
- mean Omega_A: 0.2641141776
- mean lambda_collar: 0.9343006395
- mean source suppression fraction: 0.05500142294
- mean CDM-like S8: 0.828924043
- mean direct-Jacobi S8: 0.79
- mean matrix-gap S8: 0.826611732
- mean Lane-8 I0 bits: 63.4040867
- mean Lane-8 low-entropy gap bits: 55.4040867
- mean Lane-8 fake gamma margin bits: -30
- mean Planck H0 pull sigma: 0.074126931
- mean SH0ES H0 pull sigma: -5.423049478
- mean weak-lensing CDM S8 pull sigma: 2.432752687
- interpretation: H0/S8 branch diagnostic from the OPH cosmology notes. The numbers are measurement-facing branch consequences. Lane-8 certificate fields expose record/provenance closure gates, but they become finite-lattice predictions only when Q_A, B_A(k,a), the repair clock, CAMB/CLASS anomaly module, likelihood gates, and run-derived Lane-8 certificate values are closed.

## OPH-CMB Anomaly-Stress Adapter

- adapter reports: 0
- Boltzmann-ready reports: 0
- physical-prediction-ready reports: 0
- cosmology perturbation receipts: 0
- mean finite-collar sample count: n/a
- mean weighted collar repair defect R: n/a
- mean rho_A_eq proxy: n/a
- mean diagnostic kernel rows: n/a
- mean missing gate count: n/a
- interpretation: OPH-CMB adapter lane from the CMB writeup. It preserves standard photon-baryon recombination physics and exposes the OPH anomaly sector quantities needed by a future CAMB/CLASS module. Current values are finite-collar parent diagnostics, not theorem-grade rho_A(a), Gamma_rec, or B_A(k,a), so the Boltzmann gate remains closed.

## Screen Holonomy Defect Proxy

- runs with holonomy reports: 0
- mean defect fraction: n/a
- mean cluster count: n/a

## Defect Worldline / Particle Precursors

- runs with defect-worldline diagnostics: 1
- timeline reports: 0
- interaction reports: 0
- particle-likeness reports: 1
- H3 worldline reports: 0
- screen-worldline precursor receipts: 0
- interaction proxy receipts: 0
- H3 bulk-worldline precursor receipts: 0
- particle-matter receipts: 0
- mean worldline count: n/a
- mean persistent worldline count: n/a
- mean max observation count: n/a
- mean max lifetime cycles: n/a
- mean screen transport proxy count: n/a
- mean fusion candidate count: n/a
- mean particle-like count: 0

## Controlled Defect Particle Assay

- controlled assay reports: 0
- inverse-identity passes: 0
- interaction proxy receipts: 0
- fusion-conservation passes: 0
- detector-positive receipts: 0
- physical particle-emergence receipts: 0
- mean controlled particle-like count: n/a
- interpretation: Controlled planted S3 inverse-defect assay. Positive counts validate the particle-gate logic on known transport/fusion/scattering structure. They do not count as spontaneous matter emergence in production OPH-FPE dynamics.

## Output Files

- `comparable_data_snapshot.json`
- `comparable_data_rows.csv`
- `comparable_data_snapshot.md`
