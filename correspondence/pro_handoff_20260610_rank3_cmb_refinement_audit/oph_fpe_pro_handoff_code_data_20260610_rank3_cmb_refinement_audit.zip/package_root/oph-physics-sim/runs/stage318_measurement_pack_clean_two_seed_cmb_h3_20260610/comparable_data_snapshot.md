# OPH-FPE Comparable Data Snapshot

Comparable-data snapshot for current OPH-FPE receipts. Planck comparisons are shape-only C_l diagnostics with normalized axes and amplitude rescaling. OPH-screen CAMB transfer reports are solver scaffolds unless their screen-power input is simulator-derived and passes the finite eta/readiness gates. OPH-CMB anomaly-stress and inflation/CMB bridge reports are continuation diagnostics, not finite-lattice derivations. adapter values are finite-collar parent diagnostics, not CAMB/CLASS anomaly-module outputs. H3 values are internal modular-response-vs-control receipts. Defect values are screen/collar holonomy proxies. The top-level bulk flag requires every comparable seed in the selected run set to pass a non-boundary H3 object-population gate or strict neutral third-person bulk gate. H3 preview alone is reported separately. This is not a physical CMB prediction, not a P(k), not a Boltzmann likelihood, and not a completed particle-emergence result.

## Current Answer

Yes: the current simulator emits diagnostic, measurement-facing values and a theorem-assisted populated-H3 chart receipt on the paper route. No: it does not yet emit a physical CMB prediction, physical P(k), strict neutral third-person bulk reconstruction, or particle spectrum.

- comparable rows: 27
- theorem-assisted H3 bulk any/count: True / 1
- chart-level 3+1D any/count: True / 2
- strict neutral 3D bulk any/count: False / 0
- all selected rows bulk-established: False
- exact OPH target n_s: 0.964841143
- exact OPH target CAMB IR shape correlation: 0.9998566989
- exact OPH target CAMB IR chi2/bin: 0.9509132707
- finite transition-clock n_s: 0.9674775146
- finite transition-clock kappa_rep: 2.514452654
- finite transition-clock certified count: 0
- finite transition required repair-step time for kappa=e: 45.77617281
- screen Planck-lite best shape correlation: 0.2394788976
- physical CMB prediction: False

## Support-Visible Lorentz Branch

- runs with Lorentz split receipts: 3
- chart-level conformal Lorentz receipts: 3
- BW automorphism sanity receipts: 3
- support-visible 3+1D Lorentz receipts: 3
- endogenous modular-generator receipts: 0
- paper-theorem 3D bulk-chart receipts: 3
- paper-theorem H3 spatial dimension mean: 3
- paper-theorem object-populated chart precursors: 0
- paper-theorem neutral populated bulk receipts: 0
- support-visible record H3 population receipts: 1
- support-visible defect H3 population receipts: 2
- support-visible populated-H3 bulk receipts: 1
- mean record-family H3 residual: 0.08650427093
- mean defect-cluster H3 residual: 0.00204375024
- paper-theorem-assisted H3 chart precursor receipts: 2
- paper-theorem-assisted populated H3 chart receipts: 1
- theorem-assisted H3 object-preview receipts: 2
- object H3 nonboundary population receipts: 1
- object bulk-population receipts: 1
- bulk-proof certificates: 2
- bulk-proof chart-level 3+1D counts: 2
- bulk-proof theorem-assisted H3 preview counts: 2
- bulk-proof theorem-assisted nonboundary H3 counts: 1
- bulk-proof legacy theorem-assisted populated H3 counts: 1
- bulk-proof strict neutral 3D counts: 0
- bulk-proof screen-CMB proxy counts: 2
- bulk-proof physical CMB counts: 0
- bulk-proof production particle counts: 0
- screen-proxy CMB receipts: 3
- bulk-established count: 1
- interpretation: Splits the paper-side chart-level Lorentz receipt from later strengthening receipts. A support-visible Lorentz count means conformal H3 chart plus direct BW/KMS automorphism sanity; a paper-theorem 3D bulk chart count means the simulator has verified the exact chart route Conf+(S2) -> SO+(3,1) -> H3 with boost-orbit dimension 3, rather than fitting a finite point cloud dimension. A support-visible populated-H3 count means persistent record-family support profiles populate that H3 chart under S2-boundary and shuffled-cap controls. Defect-cluster support in H3 is reported separately as a matter/particle precursor. a theorem-assisted object-preview count means the Lorentz chart, BW automorphism sanity, intermediate H3 response control separation, and localized observer-object H3 preview are all present. A nonboundary population count is stricter and requires the boundary leakage audit to pass. Both remain separate from the strict finite endogenous-generator bulk proof and from particles/physical cosmology. The bulk-proof certificate counts make this split explicit: chart-level 3+1D, theorem-assisted H3 preview, nonboundary H3 population, strict neutral bulk, screen-CMB proxy, physical CMB, and production particles are separate gates.

## State-Derived BW Matrix Elements

- runs with state-derived BW reports: 3
- endogenous-generator runs: 0
- declared cap-flow generator runs: 0
- declared response-density runs: 0
- direct transition-automorphism runs: 3
- BW/KMS receipts: 3
- density-log calibration receipts: 0
- endogenous correct-beats-controls count: 0
- selected-2pi count: 3
- state-mode counts: {'transition_response_unitary': 3}
- generator-scale counts: {'1': 3}
- best-control counts: {'no_modular_flow': 2, 'wrong_1x_normalization': 1}
- target-scale degenerate-control runs: 0
- degenerate target-scale control counts: {}
- generator-scale audit runs: 0
- generator audit configured-best count: 0
- generator audit 2pi-best count: 0
- generator audit best-label counts: {}
- generator audit diagnosis counts: {}
- mean generator-audit best score: n/a
- mean generator-audit configured score: n/a
- mean median residual: 1.91725434e-15
- mean endogenous median residual: n/a
- mean declared cap-flow median residual: n/a
- mean declared response-density median residual: n/a
- mean direct transition median residual: 1.91725434e-15
- mean wrong-1x median: 0.6640379583
- mean wrong-pi median: 0.665454722
- mean no-modular-flow median: 0.6988165667
- interpretation: Only direct transition-automorphism BW receipts pass in this run set. Those are useful finite support-visible sanity receipts for the declared 2pi transport. They are counted with the conformal H3 chart in the separate Lorentz branch lane; they are not endogenous observer-record modular generators and do not establish a populated bulk.

## Declared Shape Substrate Witness

- Shape reports: 0
- vertex-scattering receipts: 0
- dodeca cell receipts: 0
- settling receipts: 0
- loop-particle receipts: 0
- screen-projection receipts: 0
- selector-elimination target input receipts: 0
- CMB-certificate input receipts: 0
- declared-3D-substrate reports: 0
- neutral OPH bulk claims: 0
- physical-CMB prediction claims: 0
- mean q_IR target: n/a
- mean q_IR runtime zero-mode: n/a
- mean ell_IR target: n/a
- mean ell_IR runtime covariance rank: n/a
- mean Phi drop fraction: n/a
- mean loop-particle count: n/a
- mean Planck-lite shape correlation: n/a
- mean Planck-lite RMSE: n/a
- interpretation: This lane tests declared dodecahedral three-way scattering, loop modes, loop particles, screen-projection diagnostics, and selector-elimination target inputs such as q_IR=1/4 and ell_IR=32. It is useful as a controlled substrate witness and C_l diagnostic source, but it must not be counted as neutral OPH bulk emergence or a physical CMB prediction.

## Static Galaxy Proxy

- galaxy proxy reports: 3
- proxy receipts: 3
- runs with external RAR/BTFR/disk data: 0
- RAR lambda-fit count: 0
- BTFR fit count: 0
- disk residual count: 0
- mean declared a0_OPH: 1.2e-10
- mean effective a0: 1.2e-10
- mean declared lambda_collar: 1
- mean fitted lambda_collar: n/a
- mean BTFR slope: n/a
- interpretation: Static galaxy lane for OPH RAR/BTFR continuation diagnostics. Current run-bundle outputs are proxy surfaces unless external SPARC/RAR/BTFR rows are supplied, so this is measurement-facing scaffolding rather than a publication-grade galaxy likelihood.

## Static Galaxy Measurement Fit

- external fit reports: 0
- RAR/BTFR receipts: 0
- OPH-CET bridge receipts: 0
- claim-tier counts: {}
- physical-claim fit reports: 0
- physical-CMB claim reports: 0
- bulk-required reports: 0
- mean dataset galaxy count: n/a
- mean measurement galaxy count: n/a
- mean RAR galaxy count: n/a
- mean RAR galaxy support count: n/a
- mean RAR point count: n/a
- mean RAR scatter dex: n/a
- mean BTFR slope: n/a
- mean BTFR predicted slope from RAR fit: n/a
- mean BTFR slope delta: n/a
- mean BTFR intercept delta dex: n/a
- holdout usable reports: 0
- holdout receipts: 0
- mean holdout train/test galaxies: n/a / n/a
- mean holdout train/test points: n/a / n/a
- mean holdout shared a0: n/a
- mean holdout shared lambda_collar: n/a
- mean holdout train log-accel RMSE dex: n/a
- mean holdout test log-accel RMSE dex: n/a
- mean holdout test velocity RMSE km/s: n/a
- mean holdout baryon-only velocity RMSE km/s: n/a
- mean holdout velocity RMSE improvement: n/a
- interpretation: External static-galaxy OPH-CET bridge lane. It calibrates the OPH continuation law on RAR acceleration rows with free a0/lambda_collar and reports the asymptotic BTFR implied by that fit when BTFR rows exist. The optional SPARC mass-model holdout splits by galaxy and fits only shared a0/lambda_collar with fixed M/L assumptions. It is measurement-facing static phenomenology; it does not require the populated-bulk gate and is not a physical CMB/P(k) prediction.

## Minimal Caps-To-H3 Calibration

- calibration reports: 1
- calibration receipts: 1
- mean median reconstruction MSE: 5.825938082e-34
- mean shuffled profile MSE: 0.2241479629
- mean S2-boundary profile MSE: 0.2511130521
- H3 beats shuffled count: 1
- H3 beats S2-boundary count: 1
- claim boundary: S2 cap-profile to H3 geometry calibration only; not a dynamics or populated-bulk claim.

## H3 Seed Ensemble Robustness

- ensemble reports: 0
- response seed-robust receipts: 0
- chart-3D seed-robust receipts: 0
- mean seed count: n/a
- mean single-seed receipt fraction: n/a
- mean control-separation fraction: n/a
- mean candidate receipt fraction: n/a
- mean 3D-window fraction: n/a
- mean heldout normalized RMSE: n/a
- mean heldout explained variance: n/a
- mean p75 material wrong-scale fraction: n/a
- interpretation: Cached H3 seed-ensemble robustness. This prevents accepting a single lucky H3 candidate sample as bulk evidence. The response ensemble receipt uses aggregate control separation, median explained variance, and p75 material wrong-scale fraction; per-seed candidate receipts remain diagnostic because their single-seed gate is stricter. This is still not a populated bulk receipt.

## H3 Modular-Response Receipt

- runs with H3 fits: 3
- H3 receipts: 1
- H3 control-separation precursor receipts: 3
- mean H3 RMSE: 0.95484968
- mean H3 explained variance: 0.08800167422
- H3 channel modes: {'time_observable_class': 3}
- H3 profile modes: {'static_halfspace': 3}
- mean H3 channel count: 75
- H3-chart 3D-window count: 1
- H3-chart estimator-agreement count: 1
- staged signal gate count: 3
- staged geometry gate count: 3
- staged aggregate wrong-scale gate count: 3
- staged material feature gate count: 1
- mean H3-chart correlation dimension: 1.605397244
- mean H3-chart local-MLE dimension: 3.122246803
- mean S2-boundary RMSE: 0.9815355768
- mean shuffled-response RMSE: 1.003624009
- strict wrong-scale feature audits: 3
- mean wrong-scale feature win fraction: 0.4523596177
- mean 2pi/H3 feature win fraction: 0.5476403823
- wrong-scale red-flag runs: 3
- mean material wrong-scale win fraction: 0.1696721924
- mean material 2pi/H3 win fraction: 0.8303278076
- material wrong-scale red-flag runs: 3
- worst wrong-scale group sample: {'cap_index': 6, 'time_index': 0, 'time': 0.125, 'observable': 'record_family', 'feature_type': 'class_distribution_delta', 'feature_count': 3, 'winner_counts': {'2pi_h3_fit': 0, '1x': 3, '4pi': 0, 'pi': 0}, 'material_winner_counts': {'2pi_h3_fit': 3, '1x': 0, '4pi': 0, 'pi': 0}, 'wrong_scale_win_fraction': 1.0, 'material_wrong_scale_win_fraction': 0.0, 'median_h3_feature_rmse': 1.0588233050023634, 'median_best_wrong_scale_rmse': 1.057238665624802}

## Observer Readout Consensus

- runs with observer readout reports: 3
- mean observer count: 725.6666667
- mean overlap pair count: 1415.666667
- mean global committed fraction: 1
- mean median overlap Jaccard: 0.1058349725
- mean median signature similarity: 0.7078993056
- mean p10 signature similarity: 0.4199652778
- mean object overlap agreement: 0.291883548
- mean object p10 overlap agreement: 0.2486115524
- mean counterfactual stability: 1
- bad record rewrite detections: 0

## Observer-Chart Object Population

- runs with object-chart reports: 2
- object-chart receipts: 1
- object-chart median receipts: 2
- object-chart H3 control-separation receipts: 2
- localized-object precursor receipts: 1
- bulk-population receipts: 1
- mean object count: 1047.5
- mean localized object count: 961.5
- mean localized non-boundary object count: 955
- mean shuffle control count: 16
- mean shuffled localized object count: 955.5
- mean shuffled localized object p90: 970.25
- mean H3 compactness: 0.1292439089
- mean S2-boundary compactness: 0.5278759547
- mean shuffled-H3 compactness: 0.1416117286
- mean p10 shuffled-H3 compactness: 0.1364540073
- mean p90 shuffled-H3 compactness: 0.1534284787
- mean H3 margin vs median shuffle: 0.08821333977
- mean H3 margin vs p10 shuffle: 0.05374948959
- mean H3 margin vs S2 boundary: 0.7436019365
- H3 beats median shuffle count: 2
- H3 beats robust shuffle count: 2
- compactness-distribution control receipts: 2
- compactness-distribution strict population receipts: 1
- localized-count saturation warnings: 0
- localized non-boundary saturation warnings: 0

## Neutral Observer Reconstruction

- runs with neutral reconstruction reports: 2
- legacy neutral reconstruction reports: 2
- strict-neutral reports: 2
- strict-neutral bulk receipts: 0
- strict-neutral H3 selected count: 0
- strict-neutral H3 best count: 0
- strict-neutral estimators-agree-3D count: 0
- strict-neutral S2-leakage-pass count: 0
- mean strict-neutral observer count: 1056.5
- mean strict-neutral median dimension: n/a
- mean strict-neutral correlation dimension: 8.938876241
- mean strict-neutral local-MLE dimension: n/a
- mean strict-neutral S2-distance correlation: 0.1856136396
- radial-depth-used count: 0
- control-gate passed count: 2
- candidate 3D-window count: 1
- bulk-established count: 0
- estimators-agree count: 2
- mean primary dimension: 2.539162653
- mean correlation dimension: 2.539162653
- mean local-MLE dimension: 2.896690606
- blind usable count: 2
- blind S2-leakage-pass count: 2
- blind candidate 3D-window count: 0
- blind low-rank usable count: 2
- blind low-rank selected 3D-candidate count: 0
- blind low-rank selected 3D-window count: 0
- blind low-rank selected S2-leakage-pass count: 2
- blind record-transition rank-3 receipt count: 1
- blind record-transition rank-3 3D-window count: 1
- blind record-transition rank-3 estimator-agreement count: 2
- blind record-transition rank-3 S2-leakage-pass count: 2
- blind bulk-established count: 0
- mean blind feature width: 55
- mean blind S2-distance correlation: 0.06740828714
- mean blind correlation dimension: 8.044259491
- mean blind local-MLE dimension: 11.80334993
- mean blind low-rank participation rank: 9.785051763
- mean blind low-rank entropy rank: 15.96780399
- mean blind low-rank selected rank: 8
- mean blind low-rank selected correlation dimension: 5.494806512
- mean blind low-rank selected local-MLE dimension: 6.334541979
- mean blind low-rank selected S2-distance correlation: 0.05341720631
- mean blind record-transition rank-3 correlation dimension: 2.700583317
- mean blind record-transition rank-3 local-MLE dimension: 2.950846379
- mean blind record-transition rank-3 S2-distance correlation: 0.004779754415

## Planck-Lite Screen C_l Shape

- runs with CMB-lite comparisons: 4
- best-field counts: {'record_signature_smooth_k32': 2, 'stable_count': 1, 'scale_compressed_repair': 1}
- best-positive-field counts: {'record_signature_smooth_k32': 2, 'None': 1, 'scale_compressed_repair': 1}
- best real-ell overlap field counts: {'scale_compressed_repair': 1}
- mean best-field correlation: 0.2394788976
- mean best-field RMSE: 0.843805325
- mean best-positive-field correlation: 0.5716224555
- mean best-positive-field RMSE: 0.7917404333
- mean record-signature correlation: 0.07731911835
- mean record-signature RMSE: 0.9330808629
- real-ell overlap usable runs: 1
- mean record-signature overlap-ell correlation: -0.2523093697
- mean record-signature overlap-ell RMSE: 1
- mean overlap ell range: [47.711224, 512]
- mean overlap benchmark bins: 16
- best real-ell overlap usable runs: 1
- mean best real-ell overlap correlation: 0.8001490536
- mean best real-ell overlap RMSE: 0.5998012105
- mean best real-ell overlap range: [47.711224, 2499.024]
- mean best real-ell overlap benchmark bins: 83

## Finite-Screen CMB Anomaly Readouts

- anomaly reports: 2
- primary-field counts: {'record_signature': 2}
- best low-power field counts: {'s3_class_density': 1, 'stable_count': 1}
- best large-angle field counts: {'s3_class_density': 2}
- best parity field counts: {'record_signature_smooth_k32': 2}
- best tilt field counts: {'record_signature_smooth_k32': 2}
- mean best low-power fraction: 0.2314168306
- mean best S1/2 scalar proxy: 5.465098008e-09
- mean best parity log deviation: 6.041097817
- mean best eta_R: -0.2442094003
- mean best n_s proxy: 1.2442094
- mean low-power-suppressed field count: 0
- mean large-angle-suppressed field count: 0
- mean parity-asymmetric field count: 7
- mean Planck-tilt-compatible field count: 0
- mean total entropy capacity: 106887.1326
- mean sqrt-N ell capacity proxy: 511
- physical-CMB prediction reports: 0
- interpretation: Finite-screen anomaly readout from actual C_l receipts. It targets the OPH CMB bridge questions about scale tilt, low multipoles, odd/even parity, large-angle correlations, and finite screen capacity. It is screen-only: no photon-baryon transfer, no official Planck likelihood, and no 3D-bulk proof.

## CMB Screen-Basis Transfer

- transfer reports: 0
- diagnostic receipts: 0
- mean train correlation: n/a
- mean train RMSE: n/a
- mean test correlation: n/a
- mean test RMSE: n/a
- mean max control test correlation: n/a
- mean test-control correlation gap: n/a
- mean bootstrap test correlation [p05, p95]: [n/a, n/a]
- mean bootstrap test RMSE [p05, p95]: [n/a, n/a]
- interpretation: Cross-scale screen-basis transfer is the strongest current Planck-facing diagnostic. It fits weights using observed Planck TT shape and checks transfer across patch counts against target/field-shuffle controls, so it is useful evidence about screen-statistic structure but not a physical CMB prediction.

## CAMB LambdaCDM Baseline

- baseline reports: 0
- CDM-limit Boltzmann receipts: 0
- OPH anomaly-module-ready reports: 0
- mean shape correlation: n/a
- mean normalized RMSE: n/a
- mean amplitude-fit chi2/bin: n/a
- mean best-fit-column chi2/bin: n/a
- mean first peak ell: n/a
- mean benchmark first peak ell: n/a
- mean absolute fractional error: n/a
- interpretation: External LambdaCDM CAMB baseline for CDM-limit/Boltzmann plumbing. This lane should match the local Planck TT benchmark reasonably well and gives us a regression target for any future OPH anomaly module. It is not an OPH prediction because all cosmological parameters are external defaults and no repair/anomaly source term is injected.

## OPH Screen-Power Effective Theory

- screen-power reports: 2
- simulator primordial-ready reports: 0
- physical-CMB prediction reports: 0
- mean source run count: 2.5
- mean fit row count: 2.5
- mean available fit count: 2.5
- best Planck-eta field counts: {'record_signature': 1}
- reference-source counts: {'paper_maxent_green_spectrum_plus_selector_elimination_not_finite_lattice': 1, 'simulator_eta_R_diagnostic_outside_planck_target': 1}
- mean reference eta_R: -0.5593479018
- mean reference n_s: 1.559347902
- mean simulator record-signature eta_R: -1.159385284
- mean simulator stable-count eta_R: n/a
- interpretation: OPH screen-power effective-theory bridge. This is where finite screen C_l fields are converted into eta_R/n_s and a primordial-table scaffold. If simulator_primordial_ready_count is zero, the exported reference table is either a phenomenological Planck-target fallback or a deliberately labeled failed finite diagnostic, not a simulator-ready primordial prediction.

## OPH Screen CAMB Transfer

- OPH-screen CAMB reports: 0
- transfer receipts: 0
- simulator eta-ready reports: 0
- physical-CMB prediction reports: 0
- reference-source counts: {}
- mean eta_R: n/a
- mean n_s: n/a
- mean shape correlation: n/a
- mean normalized RMSE: n/a
- mean amplitude-fit chi2/bin: n/a
- mean first peak ell: n/a
- mean benchmark first peak ell: n/a
- mean absolute fractional error: n/a
- interpretation: CAMB TT transfer from the OPH screen-power scalar scaffold. A transfer receipt means CAMB plumbing and Planck TT comparison are working. It is a physical OPH prediction only when the input screen report is simulator-derived, passes the simulator_eta_ready/readiness gates, and the downstream finite-certificate gates pass.

## OPH MaxEnt Green-Spectrum Source

- source reports: 1
- source receipts: 1
- flat-Green receipts: 1
- IR theorem receipts: 1
- source-packet audits: 1
- repair-clock certificates: 0
- bandlimit-for-IR counts: 1
- bandlimit-for-requested-ell counts: 1
- finite-lattice-derived reports: 0
- physical-CMB prediction reports: 0
- mean eta_R: 0.03515885697
- mean n_s: 0.964841143
- mean q_IR: 0.25
- mean ell_IR: 32
- mean N_frz proxy: 1089
- mean F_IR(ell=2): 0.7514164268
- mean F_IR(ell=32): 0.9080301397
- interpretation: Paper-side finite-screen CMB source certificate. This lane verifies the MaxEnt inverse-Laplacian screen covariance, selector-eliminated q_IR/ell_IR target, and a CAMB/CLASS primordial-table scaffold. The finite repair-clock certificate kappa_rep=e, finite freezeout emission, parity/BipoSH covariance, and official likelihood gates remain separate.

## OPH Repair-Clock Kappa Audit

- repair-clock reports: 1
- finite repair-clock certificates: 0
- eta_R finite-lattice-derived reports: 0
- cycle-time normalization declared reports: 0
- mean candidate run count: 4
- mean estimator count: 4
- mean eligible estimator count: 0
- mean passed estimator count: 0
- mean median kappa_rep estimate: 16.91187547
- target kappa_rep: 2.718281828
- mean median eta_R estimate: 0.218741929
- target eta_R: 0.03515885697
- mean blocker count: 2
- interpretation: Finite repair-clock audit for the exact OPH CMB scalar tilt eta_R=kappa_rep*(P-phi). This is the remaining dynamic certificate after q_IR and ell_IR selector elimination. Diagnostic trace fits are kept visible, but the lane does not certify a physical CMB prediction unless theorem-grade eligible rows derive kappa_rep=e under declared controls.

## OPH Scalar Repair-Semigroup Gap

- semigroup reports: 3
- algebraic target receipts: 0
- repair-clock certificates: 0
- eligible certificate reports: 0
- finite-lattice-derived reports: 3
- sources: ['finite_state_transition_matrix']
- mean dimension: 2
- mean centered dimension: 1
- mean kappa_rep: 2.514452654
- mean eta_R: 0.03252248545
- mean n_s: 0.9674775146
- mean centered gap: 0.03252248545
- mean primary lambda_2: 0.2
- mean required repair-step time for kappa=e: 45.77617281
- transition clock certified reports: 0
- controls-passed reports: 3
- interpretation: Scalar repair-semigroup gap lane for the exact OPH CMB clock. A declared Euler target only checks the algebraic route to kappa_rep=e. A finite support-visible transition matrix is stronger, but it still certifies the CMB clock only if its declared repair-step normalization yields kappa_rep=e under the report controls.

## OPH Inflation/CMB Bridge

- bridge reports: 0
- v0.4 public-data diagnostic reports: 0
- physical-CMB prediction reports: 0
- mean n_s = 1 - P/48: n/a
- mean theta_OPH = P/48: n/a
- mean A_zeta: n/a
- mean n_s pull vs Planck target: n/a
- mean selected Omega_K: n/a
- mean residual Omega_A0: n/a
- mean rho_A/rho_b: n/a
- mean OPH IR q_IR: n/a
- mean OPH IR ell_IR: n/a
- mean CAMB LCDM low-ell chi2: n/a
- mean CAMB OPH-IR low-ell chi2: n/a
- mean LCDM R_OE upper-tail PTE: n/a
- mean OPH parity R_OE upper-tail PTE: n/a
- v0.5 TT low-ell delta chi2: n/a
- v0.5 TE low-ell delta chi2: n/a
- v0.5 EE low-ell delta chi2: n/a
- v0.5 TT high-ell delta chi2, ell=30..1200: n/a
- v0.5 combined TT+TE+EE low-ell delta chi2: n/a
- v0.5 pressure/not-yet-run gate count: n/a
- interpretation: Continuation bridge imported from the Pro CMB/inflation notes. It supplies P/48 screen-spectrum numbers, zero-holonomy flat-sector bookkeeping, and measured Planck low-ell/CAMB diagnostic ladders including v0.5 TT/TE/EE hard-gate proxies. It is not a finite-lattice derivation of those numbers and not an official Planck likelihood.

## OPH Inflation Certificate Stack

- certificate reports: 0
- stack-ready reports: 0
- physical-CMB prediction reports: 0
- physical matter-power prediction reports: 0
- no-data-use firewall count: 0
- scalar/edge/anomaly/parent/repair/boltzmann gates: 0 / 0 / 0 / 0 / 0 / 0
- mean found/passed/expected certificates: n/a / n/a / n/a
- mean missing certificate count: n/a
- mean A_zeta: n/a
- mean n_s: n/a
- mean Q_A: n/a
- mean B_A: n/a
- mean Gamma_rec: n/a
- interpretation: Finite certificate stack for the inflation-free OPH cosmology branch. This lane is the artifact contract for A_zeta, n_s, Q_A, B_A(k,a), Gamma_rec(k,a), and Boltzmann handoff. The current report is a physical prediction only when all finite certificates and the no-data-use firewall pass before likelihood comparison.

## OPH Finite Certificate Authority

- finite certificate bundles: 0
- compiler-ready bundles: 0
- legacy stack-ready bundles: 0
- theorem-grade finite-input bundles: 0
- proxy-certificate bundles: 0
- no-data-use receipts: 0
- release-code gates: 0
- parent-collar gates: 0
- repair-matrix gates: 0
- Boltzmann-export gates: 0
- real-physics certificate bundles: 0
- physical-CMB prediction reports: 0
- mean A_zeta: n/a
- mean n_s: n/a
- mean Q_A: n/a
- mean B_A: n/a
- mean Gamma_rec: n/a
- interpretation: Finite OPH cosmology certificate authority. This lane computes A_zeta, Q_A, B_A(k,a), Gamma_rec, and a Boltzmann handoff contract from finite release/collar/repair inputs. Compiler-ready means certificate artifacts are internally consistent, not theorem-grade. Toy/proxy inputs validate the compiler only; physical CMB and matter-power gates remain closed until real simulator regulator data and cold-limit solver receipts pass the firewall.

## OPH Scalar Geometric Quotient

- scalar quotient reports: 1
- scalar quotient receipts: 1
- finite-ready scalar releases: 0
- active 33-level clauses: 1
- theorem-grade release codes: 0
- physical-CMB prediction reports: 0
- mean n_s: 0.9660214956
- mean observer level proxy: 33
- mean patch capacity level proxy: 512
- interpretation: Finite observer-visible scalar/geometric quotient lane. This is the direct instrumentation needed before CMB promotion: scalar packets, center-free scalar screen fields, P/48 readout, and the 33-level freezeout clause are audited separately. A scalar quotient receipt is not a physical CMB prediction unless finite-ready, theorem-grade release, parent-collar, repair, and likelihood gates also pass.

## Neutral Distance Profile Audit

- profile audit reports: 2
- strict-ready profile count: 0
- all-profile best models: {'H4': 2}
- scalar-response best models: {'H3': 2}
- prime-geometric best models: {'H2': 2}
- prime control-quotient best models: {'H2': 2}
- prime rank-3 best models: {'H3': 2}
- prime rank-8 best models: {'H4': 2}
- prime control-quotient rank-3 best models: {'H3': 2}
- prime control-quotient rank-8 best models: {'H4': 2}
- support-visible best models: {'H2': 2}
- mean all-profile corr/local-MLE dimension: 9.032606619 / 8.783862237
- mean all-profile S2 leakage corr: 0.1727866352
- mean scalar-response corr/local-MLE dimension: 7.247550465 / 10.29585522
- mean scalar-response S2 leakage corr: 0.120994091
- mean prime-geometric corr/local-MLE dimension: 10.07484739 / 8.055577397
- mean prime-geometric S2 leakage corr: 0.1527180668
- mean prime control-quotient corr/local-MLE dimension: 11.15785461 / 9.167024634
- mean prime control-quotient S2 leakage corr: 0.0002982219918
- mean prime rank-3 corr/local-MLE dimension: 1.007018923 / 1.017153688
- mean prime rank-3 S2 leakage corr: 0.1493347411
- mean prime control-quotient rank-3 corr/local-MLE dimension: 0.9847941171 / 1.006251451
- mean prime control-quotient rank-3 S2 leakage corr: -0.002187243618
- mean prime rank-8 corr/local-MLE dimension: 2.680027528 / 2.748055534
- mean prime rank-8 S2 leakage corr: 0.2532760741
- mean prime control-quotient rank-8 corr/local-MLE dimension: 2.880365214 / 2.908020108
- mean prime control-quotient rank-8 S2 leakage corr: -0.002041078272
- mean support-visible corr/local-MLE dimension: 10.07484739 / 8.055577397
- mean support-visible S2 leakage corr: 0.1527180668
- interpretation: Bounded diagnostic over neutral-distance feature profiles. It identifies whether the observer-visible packet is overcomplete, undercomplete, or still screen-leaky. It does not establish strict neutral 3D bulk.

## Prime-Geometric Rank Sweep

- rank-sweep reports: 4
- quotient 3D diagnostic receipts: 4
- spatial 3D candidate receipts: 0
- control-quotient spatial 3D candidate receipts: 2
- strict neutral candidate receipts: 0
- selected-rank controls written: 4
- selected-rank controls all failed: 2
- coordinate rank-3 tautology warnings: 4
- selected directional control survive/fail counts: 0 / 12
- selected coordinate control survive/fail counts: 12 / 0
- strict-ready ranks: 0
- dimension-window ranks: 6
- best-rank counts: {'10': 2, '8': 2}
- best-model counts: {'H4': 4}
- mean best-rank corr/local-MLE dimension: 2.9463633 / 2.991049055
- mean best-rank S2 leakage corr: 0.2614158851
- best 3D-window ranks: {'10': 2, '8': 2}
- best 3D-window models: {'H4': 4}
- mean best 3D-window corr/local-MLE dimension: 2.9463633 / 2.991049055
- coordinate spatial-3D-ready ranks: 0
- coordinate dimension-window ranks: 4
- coordinate best-rank counts: {'3': 4}
- coordinate best-model counts: {'E3': 4}
- coordinate mean best-rank corr/local-MLE dimension: 2.720707005 / 2.992831977
- coordinate mean best-rank S2 leakage corr: 0.1208449565
- coordinate best 3D-window ranks: {'3': 4}
- coordinate best 3D-window models: {'E3': 4}
- coordinate mean best 3D-window corr/local-MLE dimension: 2.720707005 / 2.992831977
- control quotient marked as negative control: {'False': 4}
- control-quotient strict-ready ranks: 0
- control-quotient dimension-window ranks: 4
- control-quotient best-rank counts: {'8': 4}
- control-quotient best-model counts: {'H4': 4}
- control-quotient mean best-rank corr/local-MLE dimension: 2.846832264 / 2.934636904
- control-quotient mean best-rank S2 leakage corr: 0.004389774568
- control-quotient coordinate spatial-3D-ready ranks: 4
- control-quotient coordinate dimension-window ranks: 4
- control-quotient coordinate best-rank counts: {'3': 4}
- control-quotient coordinate best-model counts: {'E3': 4}
- control-quotient coordinate mean best-rank corr/local-MLE dimension: 2.64910953 / 3.020952835
- control-quotient coordinate mean best-rank S2 leakage corr: 0.01231611605
- control-quotient coordinate best 3D-window ranks: {'None': 2, '3': 2}
- control-quotient coordinate best 3D-window models: {'None': 2, 'E3': 2}
- control-quotient coordinate mean best 3D-window corr/local-MLE dimension: 2.65147268 / 3.017951323
- control-quotient coordinate mean best 3D-window S2 leakage corr: 0.01274137816
- control-quotient coordinate best 3D-window S2 leakage-pass count: 2
- interpretation: Diagnostic low-rank quotient sweep over prime-geometric modular response and its finite-regulator control quotient. Directional/cosine rows test angular response structure; coordinate rows test whether response coordinates already carry a neutral 3D spatial chart. The control quotient is a target-response quotient with regulator-control directions removed, not a shuffled/null negative control. These are diagnostics only until controls and refinement pass.

## OPH Parent-Collar Recovery Ladder

- parent-collar ladder reports: 1
- compiler-ready reports: 1
- regulator-ladder-ready reports: 1
- scaling-pass reports: 0
- local recovery-density reports: 1
- strict local recovery-density reports: 0
- theorem-grade reports: 0
- strict cap-family reports: 0
- unique theta-family reports: 1
- physical-CMB prediction reports: 0
- mean collar report count: 9
- mean cap-row count: 68
- mean regulator patch-count count: 3
- mean log p90-CMI vs log-N slope: 0.3521384724
- mean log p90-CMI/collar vs log-N slope: -0.1499774038
- mean final p90 epsilon_CMI: 1.928689477
- mean final p90 epsilon_CMI/collar: 0.001062237532
- mean final p90 r_FR: 2.776474572
- interpretation: Finite parent-collar recovery ladder diagnostic. This aggregates cached diagonal collar-Markov CMI/Fawzi-Renner proxy reports across regulator sizes. It is the right input lane for future finite CMB certificates, but it is not theorem-grade unless the recovery errors improve with refinement and pass conservative cold-limit thresholds.

## OPH B_A Parent Finite Difference

- B_A parent reports: 2
- B_A parent receipts: 0
- paired finite diagnostic receipts: 1
- physical-prediction-ready reports: 0
- physical-CMB prediction reports: 0
- controls-fail reports: 1
- real baryon perturbation rerun reports: 1
- finite observer-view parent variation reports: 1
- refinement convergence reports: 0
- primary parent source counts: {'observer_view_finite_collar_packet_variation': 1, 'paired_cap_collar_perturb_resettle_rerun': 1}
- mean source report count: 1
- mean observer-view source count: 0.5
- mean B_A rows: 206
- mean B_A control rows: 1046
- control failure counts: {'baryon_delta_applied_after_record_freezeout': 2, 'no_perturbation': 1, 'no_repair_load_channel': 1, 'phase_shuffled_baryon_mode': 1, 'random_collar_labels': 1, 'wrong_k_label': 1}
- missing gate counts: {'real_baryon_perturbation_runs_present': 1, 'finite_collar_parent_theorem_grade': 1, 'scale_calibrated_k_h_mpc': 2, 'rho_A_of_a_physical_emitted': 2, 'rho_A_eq_of_a_physical_emitted': 2, 'Gamma_rec_of_k_a_emitted': 2, 'energy_momentum_exchange_closed': 2, 'gauge_consistency_audited': 2, 'refinement_convergence_passed': 2, 'controls_fail': 1, 'calibrated_a_evolution': 1}
- interpretation: Finite-difference B_A(k,a) parent diagnostic from observer-visible cap/collar packet variation. The paired diagnostic receipt means real plus/minus perturb-resettle reruns, sign stability, and expected control failures are present. It is still not a physical Boltzmann kernel unless k/a units are calibrated, energy exchange is closed, and refinement passes.

## OPH Screen-Capacity Closure

- screen-capacity reports: 1
- observed-branch readout reports: 1
- F(N) implemented reports: 0
- finite-simulator fixed-point solved reports: 0
- physical-CMB prediction reports: 0
- input-mode counts: {'observed_de_sitter_radius_readout': 1}
- mean N_patch bare ratio: 1.055196794e+122
- mean N_scr entropy capacity: 3.314998497e+122
- mean Lambda l_P^2: 2.843071563e-122
- mean local P-cell count for N_scr: 8.13013639e+122
- interpretation: Global cosmic record/screen-capacity closure lane. It gives the observed-branch de Sitter entropy-capacity normalization and Lambda*l_P^2 readout, while keeping ordinary finite patch counts as numerical regulators until the OPH readback map F(N) is implemented.

## OPH Repair-Scale Closure

- repair-scale reports: 2
- numeric match within 1% reports: 2
- declared 24-round reports: 2
- finite-selector-derived 24-round reports: 0
- finite-lattice-derived eta_R reports: 0
- physical-CMB prediction reports: 0
- populated-3D-bulk reports: 0
- mean |g'(P)|: 0.002787340652
- mean q per round: 358.7649035
- mean predicted N_CRC from P: 4.274424587e+122
- mean declared N_CRC: 3.314998497e+122
- mean n_s = 1-P/48: 0.9660214956
- mean 1M effective repair-round depth: 1.178287236
- interpretation: Maarten/OPH 24-round scale-closure hypothesis. This lane predicts a local repair contraction |g'(P)|=alpha/phi^2, an implied N_CRC=|g'|^-48, and n_s=1-P/48. It explains finite-regulator shallow depth, but does not derive the 24 rounds from a finite selector and does not establish populated 3D bulk or physical CMB.

## OPH Scale-Compressed Repair Branch

- compressed branch reports: 1
- operator receipts: 1
- round-trace receipts: 1
- cap-profile H3 receipts: 1
- populated-H3 preview reports: 1
- strict neutral bulk reports: 0
- particle preview reports: 1
- production particle-matter reports: 0
- physical-CMB prediction reports: 0
- mean rounds: 24
- mean eta_R: 0.03397850436
- mean n_s: 0.9660214956
- mean q_IR: 0.25
- mean ell_IR: 32
- mean object count: 2048
- mean particle worldline count: 128
- interpretation: Logical 24-round scale-compressed repair branch. This lane makes the repair-depth hypothesis computable now: it emits a round trace, OPH CMB scalar parameters, a screen C_l scaffold, and a populated H3 preview. It is not a literal finite-patch proof, not strict neutral bulk, and not a physical CMB prediction.

## OPH Scale-Compressed CMB CAMB Transfer

- CAMB transfer reports: 1
- measurement-comparable curve reports: 1
- transfer receipts: 1
- operator receipts: 1
- H3 preview receipts: 1
- physical-CMB prediction reports: 0
- mean rounds: 24
- mean eta_R: 0.03397850436
- mean n_s: 0.9660214956
- mean q_IR: 0.25
- mean ell_IR: 32
- mean LCDM shape correlation: 0.9998604572
- mean scale-compressed scalar shape correlation: 0.9998574617
- mean scale-compressed IR shape correlation: 0.9998534543
- mean LCDM chi2/bin: 0.9444957497
- mean scale-compressed scalar chi2/bin: 0.954498157
- mean scale-compressed IR chi2/bin: 0.9615050793
- mean acoustic |delta|: 0.001358594647
- interpretation: CAMB TT transfer for the logical 24-round scale-compressed repair branch. This is the current closest measurement-comparable CMB artifact tied to the repair-depth simulator readouts. It remains non-physical until the 24-round selector, amplitude, anomaly-sector, and official likelihood/map-space gates are closed.

## OPH Inflation/CMB CAMB Transfer

- CAMB transfer reports: 0
- measurement-comparable curve reports: 0
- transfer receipts: 0
- physical-CMB prediction reports: 0
- mean n_s: n/a
- mean A_zeta: n/a
- mean q_IR: n/a
- mean ell_IR: n/a
- mean LCDM high-ell shape correlation: n/a
- mean OPH P/48 high-ell shape correlation: n/a
- mean OPH P/48+IR high-ell shape correlation: n/a
- mean LCDM high-ell chi2/bin: n/a
- mean OPH P/48 high-ell chi2/bin: n/a
- mean OPH P/48+IR high-ell chi2/bin: n/a
- mean acoustic |delta|: n/a
- imported low-ell LCDM chi2: n/a
- imported low-ell OPH-IR chi2: n/a
- mean unique v0.9 n_s: n/a
- mean unique v0.9 q_IR: n/a
- mean unique v0.9 ell_IR: n/a
- mean unique v0.9 high-ell shape correlation: n/a
- mean unique v0.9 chi2/bin: n/a
- mean unique v0.9 acoustic |delta|: n/a
- interpretation: Direct CAMB TT transfer for the OPH P/48 screen spectrum plus imported v0.4 IR kernel. This lane emits an actual CMB curve and compares it with the local Planck TT benchmark table. It remains a continuation diagnostic until the finite lattice derives A_zeta, q_IR, ell_IR, and angular covariance from cap/collar microphysics.

## OPH CMB Selector Elimination v1.5

- selector-elimination reports: 2
- theorem-side receipts: 2
- source-packet audit receipts: 2
- q_IR selector-removed count: 2
- ell_IR selector-removed count: 2
- eta_R repair-clock reduction count: 2
- finite-lattice-derived reports: 0
- physical-CMB prediction reports: 0
- exact-kernel CSV pass count: 2
- mean exact-kernel CSV max error: 0
- mean n_s: 0.964841143
- mean eta_R: 0.03515885697
- mean q_IR: 0.25
- mean ell_IR: 32
- kappa_rep status counts: {'certificate_pending': 2}
- interpretation: v1.5 OPH-CMB selector-elimination lane. q_IR and ell_IR are counted as theorem-side target derivations when their receipts pass; eta_R is only reduced to a repair-clock certificate until the finite lattice derives kappa_rep=e. This lane strengthens the exact target branch but does not by itself make the CAMB curve a physical finite-lattice CMB prediction.

## OPH Exact CMB CAMB Transfer

- CAMB transfer reports: 1
- measurement-comparable curve reports: 1
- transfer receipts: 1
- physical-CMB prediction reports: 0
- official clik-ready reports: 0
- official likelihood-ready reports: 0
- embedded selector theorem receipts: 1
- embedded selector source-audit receipts: 1
- mean exact n_s: 0.964841143
- mean exact eta_R: 0.03515885697
- mean exact q_IR: 0.25
- mean exact ell_IR: 32
- mean exact N_frz proxy: 1089
- mean LCDM shape correlation: 0.9998604572
- mean exact scalar shape correlation: 0.9998605944
- mean exact IR shape correlation: 0.9998566989
- mean LCDM chi2/bin: 0.9444957497
- mean exact scalar chi2/bin: 0.9441057613
- mean exact IR chi2/bin: 0.9509132707
- mean acoustic |delta|: 7.642430139e-05
- interpretation: Native CAMB TT transfer for the exact OPH CMB target branch updated with the v1.5 selector-elimination receipts: q_IR and ell_IR are theorem-side target counts, while n_s still depends on the pending kappa_rep=e repair-clock certificate. This is measurement-comparable Boltzmann output, but remains a target/continuation diagnostic until finite lattice derivation and official Planck likelihood/map-space gates pass.

## Finite Repair-Clock CMB CAMB Transfer

- CAMB transfer reports: 2
- measurement-comparable curve reports: 2
- transfer receipts: 2
- finite-lattice clock reports: 2
- exact repair-clock certificate reports: 0
- selector IR theory-side reports: 2
- physical-CMB prediction reports: 0
- mean finite-clock n_s: 0.9672256468
- mean finite-clock eta_R: 0.03277435321
- mean finite-clock kappa_rep: 2.53392563
- mean q_IR: 0.25
- mean ell_IR: 32
- mean finite-clock scalar shape correlation: 0.9998532723
- mean finite-clock IR shape correlation: 0.9998491514
- mean finite-clock scalar chi2/bin: 0.971770732
- mean finite-clock IR chi2/bin: 0.9789784681
- mean acoustic |delta|: 0.00280636316
- interpretation: Native CAMB TT transfer using the finite transition-matrix repair clock emitted by the simulator. This is the strongest current simulator-derived CMB curve lane: n_s comes from finite repair data. It remains non-physical until the exact repair-clock certificate, selector finite-register certificate, physical source/k calibration, and official likelihood gates pass.

## OPH Unique Prediction Gate v0.9

- target reports: 0
- measurement-comparable target reports: 0
- finite-lattice-derived target reports: 0
- physical-CMB prediction reports: 0
- mean n_s: n/a
- mean eta_R: n/a
- mean Planck n_s pull: n/a
- mean q_IR: n/a
- mean ell_IR: n/a
- mean N_frz proxy: n/a
- mean parity R_OE TT(2..29): n/a
- mean sum m_nu eV: n/a
- mean neutrino f_nu: n/a
- mean small-scale neutrino suppression: n/a
- interpretation: Current v0.9 OPH-only public-comparison target lane: alpha-linked scalar tilt, exact IR kernel, parity envelope, neutrino mass sum, and compressed dark-sector rows. These are measurement-comparable targets, not finite-lattice derivations unless the derivation audit passes.

## OPH-CnuB Neutrino Background

- neutrino reports: 1
- measurement-comparable reports: 1
- finite-lattice-derived reports: 0
- physical-CMB prediction reports: 0
- physical matter-power prediction reports: 0
- background/mass/B_A/likelihood gate counts: 1 / 0 / 0 / 0
- five-of-seven kernel/projection counts: 1 / 1
- Planck+BAO / ACT / DESI strict sum-mnu pass counts: 1 / 0 / 0
- mean N_eff: 3.044
- mean sum m_nu eV: 0.09001192964
- mean lightest mass eV: 0.01745472026
- mean Omega_nu h2: 0.0009666229558
- mean f_nu: 0.006744316582
- mean small-scale suppression: -0.05395453265
- mean Planck N_eff pull sigma: 0.3176470588
- mean eta_A: 0.06569936051
- mean compressed Pi_WL target: 0.7147300876
- mean five-of-seven Pi_WL: 0.7142857143
- mean five-of-seven epsilon_A: 0.04692811465
- mean five-of-seven projected S8: 0.7900242005
- mean five-of-seven S8 pull sigma: 0.001512529599
- interpretation: Standalone OPH-CnuB relic-neutrino background lane. The weighted-cycle neutrino masses are measurement-comparable through standard relic-neutrino cosmology, while finite-lattice mass derivation, B_A(k,a), and full Boltzmann/likelihood gates remain closed.

## Finite Lattice CMB Derivation Audit

- derivation reports: 0
- ready reports: 0
- mean source run count: n/a
- mean finite eta_R: n/a
- mean eta_R absolute error: n/a
- mean scalar-quotient n_s: n/a
- mean scalar-quotient theta_OPH: n/a
- mean scalar-quotient n_s target error: n/a
- mean finite q_IR: n/a
- mean finite ell_IR: n/a
- mean collar median CMI: n/a
- interpretation: Audit of whether current finite lattice reports derive the CMB target parameters from cap/collar/screen receipts. A ready count of zero means comparable target numbers exist, but the finite simulator has not yet earned a physical CMB prediction claim.

## OPH Boltzmann Input Readouts

- input reports: 1
- CDM-limit-ready reports: 0
- diagnostic repair-table-ready reports: 1
- physical-prediction-ready reports: 0
- mean source report count: 2
- mean CDM row count: 4
- mean diagnostic row count: 32
- mean missing gate count: 9
- mean Gamma_rec/H shape proxy: 0.6385992516
- mean B_A shape proxy: -4.770489559e-18
- interpretation: Machine-readable bridge from OPH-CMB diagnostics to future CAMB/CLASS inputs. The CDM-limit rows are solver-ready only as an external LambdaCDM regression target. The repair-exchange rows are finite-collar proxy shapes and remain gated against physical prediction language.

## Finite-Collar Boltzmann Source Bundle

- source-bundle reports: 1
- diagnostic bundle receipts: 1
- physical export certificates: 0
- physical-CMB prediction reports: 0
- no-data-use reports: 1
- mean B_A rows: 64
- mean rho_A rows: 64
- mean Gamma_rec rows: 4
- mean physical missing gate count: 6
- mean |B_A|: 0.0007672576874
- mean |Gamma_rec/H|: 0.03201874992
- diagnostic missing gate counts: {}
- physical missing gate counts: {'physical_k_units_calibrated': 1, 'calibrated_a_evolution': 1, 'energy_momentum_exchange_closed': 1, 'gauge_consistency_audited': 1, 'refinement_convergence_passed': 1, 'physical_cmb_input_contract_passed': 1}
- interpretation: Consolidated finite-collar source bundle for the OPH Boltzmann/CMB bridge. A diagnostic receipt means rho_A(a), rho_A,eq(a), B_A(k,a), and Gamma_rec(k,a) source-side tables exist behind a no-data firewall. A physical certificate still requires calibrated k/a units, energy-exchange closure, refinement convergence, strict freezeout/bulk gates, CDM-limit regression, and an official likelihood-ready path.

## Finite-Collar CMB Projection

- projection reports: 1
- projection receipts: 1
- physical-k calibration receipts: 0
- physical-CMB prediction reports: 0
- mean projected B_A rows: 64
- mean background rows: 4
- mean ell range: 3.141592654 .. 8.97597901
- mean B_A: -0.0006478176402
- mean |B_A|: 0.0007672576874
- mean B_A positive fraction: 0.25
- mean log |B_A| / log ell slope: 2.866980616
- mean largest-scale B_A: -8.490780381e-05
- mean smallest-scale B_A: -0.001699223125
- interpretation: External-fiducial ell/k projection of finite-collar B_A rows. This is useful for measurement-facing plots and Boltzmann plumbing, but it does not close the physical k calibration gate because chi_* and h are declared comparison geometry rather than derived from the finite OPH screen-to-bulk scale theorem.

## Low-k Synchronization Gap

- gap audit reports: 0
- mean source run count: n/a
- low-k gap established reports: 0
- same-boundary selector reports: 0
- inflation-replacement-ready reports: 0
- mean time-resolved trace count: n/a
- mean cached proxy pass count: n/a
- mean time-resolved gap pass count: n/a
- mean global Phi gamma/cycle: n/a
- interpretation: Low-k synchronization-gap audit for OPH inflation-replacement questions. Cached final spectra and global Phi decay are useful diagnostics. Residual-field candidates report majority-mode repair/mismatch decay, but a true horizon-coherence/gap claim requires the stricter all-mode time-resolved harmonic repair gate and controls.

## Hot MaxEnt Release

- release audit reports: 0
- mean source run count: n/a
- theorem-ready release reports: 0
- mean mechanical release surfaces: n/a
- mean collar-gate passes: n/a
- mean theorem-ready source runs: n/a
- mean median release cycle: n/a
- mean collar median CMI: n/a
- interpretation: Hot-MaxEnt release audit. A mechanical release surface means repair and record commitment settle together; it becomes theorem-ready only when collar Markov/recovery errors and the physical unit/charge map also pass.

## Same-Boundary Adiabaticity

- adiabaticity audit reports: 0
- mean source run count: n/a
- established reports: 0
- mean proxy pass count: n/a
- mean max entropy residual std: n/a
- mean min common-clock correlation: n/a
- interpretation: Same-boundary adiabaticity/isocurvature proxy. Current channels are observer-visible record fields, not physical photon/baryon/neutrino fluids, so this lane remains a gate audit until the Boltzmann species map exists.

## H0/S8 Branch Diagnostic

- H0/S8 reports: 1
- physical-prediction-ready reports: 0
- Q_A/B_A/Gamma_J gate counts: 0 / 0 / 0
- lambda(P) gate count: 1
- CAMB/CLASS and likelihood gate counts: 0 / 0
- Lane-8 certificate / run-derived / ready counts: 1 / 0 / 0
- Lane-8 payload/fake/selector/refinement gate counts: 1 / 0 / 1 / 1
- mean H0 km/s/Mpc: 67.40002854
- mean Omega_m: 0.3154851573
- mean Omega_A: 0.2641141776
- mean lambda_collar: 0.9343006395
- mean source suppression fraction: 0.05500142294
- mean CDM-like S8: 0.828924043
- mean direct-Jacobi S8: 0.79
- mean matrix-gap S8: 0.826611732
- mean Lane-8 I0 bits: 63.4040867
- mean Lane-8 low-entropy gap bits: 55.4040867
- mean Lane-8 fake gamma margin bits: -30
- mean Planck H0 pull sigma: 0.074126931
- mean SH0ES H0 pull sigma: -5.423049478
- mean weak-lensing CDM S8 pull sigma: 2.432752687
- interpretation: H0/S8 branch diagnostic from the OPH cosmology notes. The numbers are measurement-facing branch consequences. Lane-8 certificate fields expose record/provenance closure gates, but they become finite-lattice predictions only when Q_A, B_A(k,a), the repair clock, CAMB/CLASS anomaly module, likelihood gates, and run-derived Lane-8 certificate values are closed.

## OPH-CMB Anomaly-Stress Adapter

- adapter reports: 3
- Boltzmann-ready reports: 0
- physical-prediction-ready reports: 0
- cosmology perturbation receipts: 0
- mean finite-collar sample count: 4
- mean weighted collar repair defect R: 1.399255582
- mean rho_A_eq proxy: n/a
- mean diagnostic kernel rows: 4
- mean missing gate count: 15
- interpretation: OPH-CMB adapter lane from the CMB writeup. It preserves standard photon-baryon recombination physics and exposes the OPH anomaly sector quantities needed by a future CAMB/CLASS module. Current values are finite-collar parent diagnostics, not theorem-grade rho_A(a), Gamma_rec, or B_A(k,a), so the Boltzmann gate remains closed.

## Screen Holonomy Defect Proxy

- runs with holonomy reports: 3
- mean defect fraction: 0.8338541667
- mean cluster count: 22.66666667

## Defect Worldline / Particle Precursors

- runs with defect-worldline diagnostics: 2
- timeline reports: 2
- interaction reports: 2
- particle-likeness reports: 2
- H3 worldline reports: 2
- screen-worldline precursor receipts: 2
- interaction proxy receipts: 2
- H3 bulk-worldline precursor receipts: 0
- particle-matter receipts: 0
- mean worldline count: 1
- mean persistent worldline count: 1
- mean max observation count: 8
- mean max lifetime cycles: 63
- mean screen transport proxy count: 1
- mean fusion candidate count: 0
- mean particle-like count: 0

## Controlled Defect Particle Assay

- controlled assay reports: 0
- inverse-identity passes: 0
- interaction proxy receipts: 0
- fusion-conservation passes: 0
- detector-positive receipts: 0
- physical particle-emergence receipts: 0
- mean controlled particle-like count: n/a
- interpretation: Controlled planted S3 inverse-defect assay. Positive counts validate the particle-gate logic on known transport/fusion/scattering structure. They do not count as spontaneous matter emergence in production OPH-FPE dynamics.

## Output Files

- `comparable_data_snapshot.json`
- `comparable_data_rows.csv`
- `comparable_data_snapshot.md`
