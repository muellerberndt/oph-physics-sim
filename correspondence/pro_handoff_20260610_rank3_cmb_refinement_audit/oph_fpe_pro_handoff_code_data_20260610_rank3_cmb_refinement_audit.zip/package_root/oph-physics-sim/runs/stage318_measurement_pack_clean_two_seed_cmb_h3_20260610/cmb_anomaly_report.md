# Finite-Screen CMB Anomaly Diagnostics

Finite observer-screen CMB-anomaly diagnostic from run C_l receipts. It can test whether screen synchronization leaves low-ell, parity, large-angle, and finite-capacity imprints. It is not a Planck likelihood, not a Boltzmann acoustic transfer, not a physical CMB prediction, and not proof of 3D bulk emergence.

## Summary

- field count: 10
- primary field: record_signature
- best low-power field: s3_class_density
- best low-power fraction: 0.2238123673
- best large-angle field: s3_class_density
- best S1/2 proxy: 6.638603898e-09
- best parity field: record_signature_smooth_k32
- best parity log deviation: 6.079209956
- best eta_R: -0.2886922358
- best n_s proxy: 1.288692236

## Capacity

- patch count: 262144
- total entropy capacity: 106887.1326
- sqrt-N ell capacity proxy: 511
- low-l capacity fraction proxy: 0.003433227539

## Question Status

- `why_nearly_scale_invariant`: screen_power_law_proxy_computed
- `why_acoustic_peaks`: not_answered_by_screen_anomaly_report
- `why_low_multipoles_anomalous`: finite_screen_low_ell_proxy_computed
- `should_there_be_parity_asymmetries`: odd_even_proxy_computed
- `should_there_be_preferred_large_angle_correlations`: scalar_proxy_only
- `finite_screen_capacity_signatures`: capacity_metadata_and_multipole_fraction_computed

## Outputs

- `cmb_anomaly_report.json`
- `cmb_anomaly_report.md`
- `cmb_anomaly_rows.csv`
