# OPH 3D Bulk And Measurement Proof Certificate

- run: `runs/stage318_measurement_pack_clean_two_seed_cmb_h3_20260610`
- chart-level 3+1D Lorentz/H3: `true`
- theorem-assisted H3 object preview: `true`
- theorem-assisted non-boundary H3 population: `true`
- scale-compressed H3 preview: `true`
- strict neutral third-person bulk: `false`
- prime-geometric quotient 3D diagnostic: `true`
- screen CMB proxy available: `true`
- scale-compressed CAMB TT curve: `true`
- physical CMB prediction: `false`
- production particle matter receipt: `false`
- scale-compressed particle preview: `true`

## Tiers

- `T0_finite_repair_core`: `true` - REPAIR_CORE_RECEIPT
- `T1_record_commit`: `true` - RECORD_COMMIT_RECEIPT
- `T2_bw_kms_2pi_branch`: `true` - BW_KMS_BRANCH_INSTANTIATION_RECEIPT
- `T3_chart_lorentz_h3`: `true` - CHART_LORENTZ_H3_RECEIPT
- `T4_h3_response_controls`: `true` - H3_RESPONSE_CANDIDATE_RECEIPT
- `T5a_theorem_assisted_h3_object_preview`: `true` - THEOREM_ASSISTED_H3_OBJECT_PREVIEW_RECEIPT
- `T5b_nonboundary_h3_object_population`: `true` - OBJECT_BULK_POPULATION_RECEIPT
- `T5c_scale_compressed_h3_preview`: `true` - SCALE_COMPRESSED_H3_PREVIEW_RECEIPT
- `T6_strict_neutral_third_person_bulk`: `false` - STRICT_NEUTRAL_3D_BULK_RECEIPT
- `T6a_prime_geometric_quotient_3d_diagnostic`: `true` - PRIME_GEOMETRIC_QUOTIENT_3D_DIAGNOSTIC_RECEIPT
- `T7_production_particles`: `false` - PROTO_PARTICLE_RECEIPT
- `T7a_scale_compressed_particle_preview`: `true` - SCALE_COMPRESSED_PARTICLE_PREVIEW_RECEIPT
- `T8_screen_cmb_proxy`: `true` - SCREEN_PROXY_CMB_RECEIPT
- `T8b_scale_compressed_camb_transfer`: `true` - SCALE_COMPRESSED_CMB_CAMB_TRANSFER_RECEIPT
- `T9_physical_cmb_prediction`: `false` - PHYSICAL_CMB_RECEIPT

## Scale-Compressed Readouts

- logical repair rounds: `24`
- n_s: `0.9660214956374176`
- eta_R: `0.033978504362582485`
- q_IR: `0.25`
- ell_IR: `32.0`
- H3 objects: `2048`
- particle worldlines: `128`
- CAMB IR shape correlation: `0.9998534542805271`
- CAMB IR normalized RMSE: `0.01711991352040137`
- CAMB IR chi2/bin: `0.7845969499786535`

## Paper Chart Readouts

- paper 3D chart receipt: `True`
- chart-level conformal Lorentz: `True`
- BW 2pi cap-flow receipt: `True`
- Lorentz group: `SO+(3,1)`
- spatial chart: `H3 = SO+(3,1)/SO(3)`
- H3 boost-orbit dimension: `3`
- H3 chart dimension: `3`
- finite point-cloud dimension estimator used: `False`

## Prime-Geometric Quotient

- diagnostic receipt: `True`
- spatial 3D candidate: `False`
- strict neutral candidate: `False`
- target 3D-window count: `2`
- coordinate 3D-window count: `1`
- best target 3D rank: `8`
- best coordinate 3D rank: `3`
- control quotient is negative control: `False`
- proof blockers: `['no_directional_rank_passes_strict_h3_model_and_leakage_gates', 'control_quotient_lane_is_not_a_negative_control', 'requires_refinement_stability_across_regulator_sizes', 'requires_independent_rank_selection_rule_before_physical_interpretation']`

## Claim Boundary

Tiered OPH proof/readout certificate. T2-T3 establish the chart-level 3+1D Lorentz/H3 branch for this run. T5a is theorem-assisted H3 preview evidence from observer objects. T5b is stricter non-boundary H3 object population evidence. T5c is a scale-compressed logical repair-round H3 preview and is intentionally not promoted to T5b/T6. T6 is stricter neutral third-person bulk reconstruction and may remain false even when T5 passes. T6a is an intermediate prime-geometric quotient diagnostic and is not promoted to T6. T8/T8b are measurement-facing screen/CAMB-transfer data only. T9 is a physical CMB prediction and remains false until finite OPH kernels feed a Boltzmann/likelihood-ready pipeline.
