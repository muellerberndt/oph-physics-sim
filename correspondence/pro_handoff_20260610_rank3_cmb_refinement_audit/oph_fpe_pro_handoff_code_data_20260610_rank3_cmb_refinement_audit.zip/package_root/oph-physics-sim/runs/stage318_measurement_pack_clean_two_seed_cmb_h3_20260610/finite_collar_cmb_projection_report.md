# Finite-Collar CMB Projection Diagnostic

External-fiducial projection of finite-collar source diagnostics onto CMB ell/k labels. This makes the current simulator data easier to compare and pass into plumbing tests, but it is not a physical OPH k-calibration, not a Boltzmann likelihood, and not a CMB prediction.

## Projection

- chi_star_mpc: 13850.0
- h: 0.6736
- ell mapping: `pi_over_theta`
- physical k calibration: `false`

## Shape

- rows: 64
- ell range: 3.141592653589793 .. 8.975979010256552
- mean B_A: -0.0006478176401978671
- mean |B_A|: 0.0007672576873835393
- positive fraction: 0.25
- log |B_A| / log ell slope: 2.8669806162776545
- largest-scale mean B_A: -8.490780381359834e-05
- smallest-scale mean B_A: -0.001699223124751919

## Readiness

- `finite_collar_source_bundle_receipt`: True
- `external_fiducial_geometry_declared`: True
- `ell_k_axes_emitted`: True
- `rho_A_background_rows_emitted`: True
- `physical_k_units_calibrated`: False
- `finite_screen_to_bulk_scale_theorem_used`: False
- `official_likelihood_ready`: False
