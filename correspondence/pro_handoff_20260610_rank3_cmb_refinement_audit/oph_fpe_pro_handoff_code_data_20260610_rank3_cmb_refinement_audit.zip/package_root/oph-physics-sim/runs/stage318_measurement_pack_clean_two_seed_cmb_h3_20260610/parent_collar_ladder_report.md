# OPH Parent-Collar Recovery Ladder

Classical diagonal collar-Markov refinement diagnostic from cached finite OPH-FPE runs. It audits whether raw cap/collar CMI, CMI per collar patch, and Fawzi-Renner proxy errors improve with regulator size. It is not the noncommutative parent-collar theorem object, not a physical CMB prediction, and not a 3D bulk proof. A failing or nonmonotone ladder is valid negative evidence about the current finite implementation.

- collar reports: 9
- cap rows: 68
- patch counts: [4096, 65536, 262144]
- strict cap family matched: False
- unique theta family matched: True
- compiler ready: True
- regulator ladder ready: True
- CMI scaling improves: False
- CMI density scaling improves: True
- local recovery-density receipt: True
- strict local recovery-density receipt: False
- parent-collar recovery ladder receipt: False
- theorem-grade parent-collar ladder: False
- physical CMB prediction: False
- diagnosis: raw collar CMI does not improve, but CMI per collar patch does improve; this is a positive local-density diagnostic and not yet a theorem-grade parent-collar receipt (raw slope=0.3521384723930972, density slope=-0.1499774037713725)

## By Patch Count

| N | cap rows | median epsilon_CMI | p90 epsilon_CMI | p90 epsilon_CMI/collar | p90 r_FR |
|---:|---:|---:|---:|---:|---:|
| 4096 | 32 | 0.391594 | 0.446453 | 0.00198443 | 1.33634 |
| 65536 | 32 | 1.05001 | 1.19111 | 0.00131571 | 2.18275 |
| 262144 | 4 | 1.71476 | 1.92869 | 0.00106224 | 2.77647 |
