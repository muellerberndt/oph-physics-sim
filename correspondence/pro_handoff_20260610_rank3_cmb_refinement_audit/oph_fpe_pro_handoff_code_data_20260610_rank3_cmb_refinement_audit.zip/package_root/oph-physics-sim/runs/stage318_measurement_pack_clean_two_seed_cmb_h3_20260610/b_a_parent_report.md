# Paired B_A Perturb/Resettle Diagnostic

- mode: `paired_cap_collar_perturb_resettle_B_A_parent_v0`
- rows: 32
- control rows: 192
- mean |B_A|: 0.0007672576873835393
- controls_fail: True
- control failures: {'no_perturbation': True, 'no_repair_load_channel': True, 'baryon_delta_applied_after_record_freezeout': True, 'phase_shuffled_baryon_mode': True, 'random_collar_labels': True, 'wrong_k_label': True}
- B_A_PAIRED_DIAGNOSTIC_RECEIPT: True
- B_A_PARENT_RECEIPT: False
- physical_cmb_prediction: False

## Control Metrics

- `baryon_delta_applied_after_record_freezeout`: mode=null_suppression, ratio=0.0, separation=1.0, corr=None, pass=True
- `no_perturbation`: mode=null_suppression, ratio=0.0, separation=1.0, corr=None, pass=True
- `no_repair_load_channel`: mode=null_suppression, ratio=0.0, separation=1.0, corr=None, pass=True
- `phase_shuffled_baryon_mode`: mode=paired_response_separation, ratio=0.596253223000433, separation=1.283448129232388, corr=-0.6466560107767532, pass=True
- `random_collar_labels`: mode=paired_response_separation, ratio=14.287260183516103, separation=14.823003297764654, corr=-0.5203169677414317, pass=True
- `wrong_k_label`: mode=paired_response_separation, ratio=0.3212682706585684, separation=0.8560719187024086, corr=0.38690357522273516, pass=True

Actual paired finite cap/collar perturb-resettle B_A parent diagnostic. No CMB data are used. Rows exercise finite screen repair dynamics, but they are not physical Boltzmann kernels until controls fail, k/a units are calibrated, repair-energy exchange is closed, and refinement convergence passes.
