# OPH MaxEnt Green-Spectrum Source

Paper-side finite-screen CMB source certificate. It verifies the MaxEnt Green-spectrum covariance and selector-eliminated q_IR/ell_IR target as a reproducible finite operator readout. The exact eta_R value uses the canonical kappa_rep=e target but the finite repair-clock certificate is still pending, so this is not a physical CMB prediction and not a final finite-lattice derivation.

## Readout

- patch count: 262144
- ell max: 256
- eta_R: 0.0351588569692
- n_s: 0.964841143031
- q_IR: 0.25
- ell_IR: 32
- MaxEnt Green receipt: True
- repair-clock certificate: False
- physical CMB prediction: False

## Remaining Certificates

- finite scalar repair-clock certificate kappa_rep=e
- finite normal-form scalar X_r emitted without CMB-target tuning
- finite freezeout branch emits q_IR=1/4 and ell_IR=32 from observer records
- parity/BipoSH angular covariance derived in a_lm space with masks
- OPH anomaly kernel B_A(k,a) and Gamma_rec(k,a) emitted for CAMB/CLASS
- official Planck likelihood/map-space tests
