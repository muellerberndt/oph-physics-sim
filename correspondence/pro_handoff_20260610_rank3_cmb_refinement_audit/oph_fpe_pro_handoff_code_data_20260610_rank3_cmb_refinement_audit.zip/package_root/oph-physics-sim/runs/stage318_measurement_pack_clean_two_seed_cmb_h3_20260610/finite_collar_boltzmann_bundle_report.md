# Finite-Collar Boltzmann Source Bundle

Finite-collar Boltzmann source bundle. The tables are source-side OPH-FPE diagnostics for rho_A(a), rho_A,eq(a), B_A(k,a), and Gamma_rec(k,a). They are not physical CMB or matter-power predictions until physical k/a calibration, energy-exchange closure, refinement convergence, strict freezeout/bulk gates, CDM-limit regression, and an official likelihood-ready path all pass.

## Readiness

- diagnostic source bundle receipt: `true`
- physical Boltzmann export certificate: `false`
- physical CMB prediction: `false`
- diagnostic missing gates: none
- physical missing gates: physical_k_units_calibrated, calibrated_a_evolution, energy_momentum_exchange_closed, gauge_consistency_audited, refinement_convergence_passed, physical_cmb_input_contract_passed

## Source Tables

- B_A rows: 64
- rho_A rows: 64
- Gamma_rec rows: 4
- mean |B_A|: 0.0007672576873835393
- mean |Gamma_rec/H|: 0.03201874992042351

## Checks

- `no_data_use_receipt`: True
- `B_A_rows_emitted`: True
- `rho_A_rows_emitted`: True
- `rho_A_eq_rows_emitted`: True
- `Gamma_rec_rows_emitted`: True
- `paired_B_A_diagnostic_receipt`: True
- `B_A_controls_fail`: True
- `finite_transition_matrix_ready`: True
- `physical_k_units_calibrated`: False
- `calibrated_a_evolution`: False
- `energy_momentum_exchange_closed`: False
- `gauge_consistency_audited`: False
- `refinement_convergence_passed`: False
- `physical_cmb_input_contract_passed`: False
