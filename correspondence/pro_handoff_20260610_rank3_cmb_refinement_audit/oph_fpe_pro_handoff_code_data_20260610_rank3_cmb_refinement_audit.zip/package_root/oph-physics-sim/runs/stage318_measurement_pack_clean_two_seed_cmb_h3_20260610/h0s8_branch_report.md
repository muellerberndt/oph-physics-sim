# OPH H0/S8 Branch Diagnostic

- Flat q_A closure H0: `67.400029` km/s/Mpc
- Omega_m: `0.315485157`
- Collar lambda / B_A_track: `0.934300639489`
- Effective source suppression: `0.055001`

## Branches

- Conserved CDM-like: `H0=67.4`, `S8=0.828924043`
- Direct Jacobi repair: `H0=67.400029`, `S8=0.790000`
- Matrix-gapped Jacobi: `H0=67.400029`, `S8=0.826612`

## Missing Gates

- Q_A_from_finite_collar_selector: `false`
- B_A_from_parent_collar_kernel: `false`
- lambda_collar_from_P_survival: `true`
- Gamma_rec_equals_Jacobi_clock: `false`
- full_CAMB_CLASS_anomaly_module: `false`
- full_likelihood_contract: `false`
- lane8_low_entropy_certificate_ready: `false`

## Claim Boundary

H0/S8 branch diagnostic from OPH cosmology notes. It computes consequences of declared branch assumptions but does not prove that finite lattice runs derive Q_A, B_A(k,a), or Gamma_rec=Gamma_J. Treat as measurement-facing continuation data until those gates close.
