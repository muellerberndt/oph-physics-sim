# Finite Repair-Clock CMB CAMB Transfer

CAMB TT transfer using the simulator-derived finite transition-matrix repair clock for the scalar tilt. The finite clock is actual simulator data when finite_lattice_derived is true. The selector IR overlay remains theory-side unless its own finite-register certificate closes. This is measurement-comparable simulator output, but not a physical CMB prediction until kappa_rep=e/repair-clock, physical k/source, official likelihood, and no-data-use gates pass.

## Simulator-Derived Clock Input

- n_s: 0.9679812501
- eta_R: 0.03201874992
- kappa_rep: 2.475506702
- matrix ready: True
- finite-lattice derived: True
- repair-clock certificate: False
- clock normalization certified: False
- source mode: oph_finite_repair_transition_clock_v0
- primary matrix: reversible_empirical
- repair step time: 50.26548246

## Selector IR Overlay

- q_IR: 0.25
- ell_IR: 32
- theorem receipt: True
- finite-lattice derived: False

## CAMB TT Comparison

### camb_lcdm_powerlaw

- usable: True
- bins: 83
- shape correlation: 0.9998604572
- normalized RMSE: 0.01670585755
- amplitude-fit chi2/bin: 0.9444957497
- first peak ell: 225.164945
- benchmark first peak ell: 225.164945

### finite_repair_clock_scalar_tilt

- usable: True
- bins: 83
- shape correlation: 0.9998504842
- normalized RMSE: 0.01729253159
- amplitude-fit chi2/bin: 0.9836766604
- first peak ell: 225.164945
- benchmark first peak ell: 225.164945

### finite_repair_clock_plus_selector_ir

- usable: True
- bins: 83
- shape correlation: 0.999846292
- normalized RMSE: 0.01753327996
- amplitude-fit chi2/bin: 0.9910099836
- first peak ell: 225.164945
- benchmark first peak ell: 225.164945

## Acoustic Preservation

- amplitude fit to LCDM over ell>=50: 1.001549432
- mean |delta| for ell>=50: 0.003714988073
- max |delta| for ell>=50: 0.007550775238

## Blockers

- finite transition matrix does not yield kappa_rep=e under the declared repair-step time

## Reproducibility

- Python: 3.13.7
- NumPy: 2.3.5
- CAMB: 1.6.6

## Output Files

- `finite_repair_clock_cmb_camb_report.json`
- `finite_repair_clock_cmb_tt_bins.csv`
- `finite_repair_clock_cmb_tt_curves.csv`
