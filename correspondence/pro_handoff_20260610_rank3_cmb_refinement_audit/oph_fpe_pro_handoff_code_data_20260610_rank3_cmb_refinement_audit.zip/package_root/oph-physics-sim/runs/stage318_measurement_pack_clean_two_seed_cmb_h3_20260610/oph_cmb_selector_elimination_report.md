# OPH CMB Selector Elimination v1.5

Selector-elimination receipt for the exact OPH-CMB target branch. q_IR=1/4 and ell_IR=32 are no longer treated as free fit selectors in this report; they are computed from the affine zero-mode reserve and dodecahedral visible-covariance rank. eta_R is reduced to the single repair-clock certificate kappa_rep=e, which is not yet derived by the finite lattice. This is therefore a theorem-side target/certificate audit, not a completed physical CMB prediction.

## Closed Target Values

- q_IR: `0.25`
- ell_IR: `32.0`
- N_frz proxy: `1089`
- eta_R canonical branch: `0.035158856969`
- n_s canonical branch: `0.964841143031`

## Receipts

- theorem-side selector elimination: `True`
- source packet audit: `True`
- finite lattice derived: `False`
- physical CMB prediction: `False`

## Source CSV Audit

- present: `True`
- passed: `True`
- audited rows: `13`
- max abs error: `0.0`

## Remaining Certificates

- finite-patch scalar repair-clock normalization kappa_rep=e
- finite-register visible-covariance noncollapse for ell_IR=32
- freezeout branch couples protected reserve to affine ell=0 sector for q_IR=1/4
- official masked Planck likelihood and map-space parity/BipoSH tests
