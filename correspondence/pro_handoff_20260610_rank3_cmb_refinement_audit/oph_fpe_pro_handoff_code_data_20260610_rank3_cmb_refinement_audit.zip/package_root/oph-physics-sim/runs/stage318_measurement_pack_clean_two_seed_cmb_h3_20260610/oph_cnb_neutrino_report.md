# OPH-CnuB Neutrino Background

- mode: `oph_cnb_neutrino_background_v0`
- mass ordering: `normal`
- masses eV: `0.017454720258, 0.019481987936, 0.053075221451`
- sum m_nu: `0.090011929645` eV
- N_eff: `3.044000`
- Omega_nu h^2: `0.000966622956`
- f_nu: `0.00674431658`
- small-scale Delta P/P approx: `-0.053955`
- Planck N_eff pull: `0.318 sigma`
- Planck+BAO sum-mnu bound passes: `True`
- DESI DR2 strict LCDM sum-mnu bound passes: `False`
- required compressed Pi_WL: `0.7147300876`

## Gates

- measurement_comparable_relic_background: `true`
- finite_lattice_mass_derivation: `false`
- Delta_N_eff_coh_channel_declared: `false`
- z6_poisson_five_of_seven_kernel_callable: `true`
- z6_poisson_five_of_seven_compressed_projection: `true`
- B_A_k_a_from_finite_collar_parent: `false`
- survey_projection_kernel_declared: `false`
- full_boltzmann_likelihood_run: `false`

## Claim Boundary

OPH-CnuB target/readout lane. The neutrino masses are imported from the OPH weighted-cycle quantitative branch and propagated through standard relic-neutrino cosmology. Do not interpret this as a finite-lattice derivation, an official Planck/DESI likelihood, or a completed OPH late-repair Boltzmann kernel.
