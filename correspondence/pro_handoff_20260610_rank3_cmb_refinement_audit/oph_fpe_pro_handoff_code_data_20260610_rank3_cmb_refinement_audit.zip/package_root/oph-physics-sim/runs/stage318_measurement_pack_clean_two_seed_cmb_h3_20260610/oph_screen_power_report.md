# OPH Screen Power Scaffold

Compatible OPH screen-power scaffold emitted by maxent_green_spectrum_report. It is a paper-side target source, not a finite simulated screen-field fit.

- reference source: paper_maxent_green_spectrum_plus_selector_elimination_not_finite_lattice
- eta_R: 0.0351588569692
- n_s proxy: 0.964841143031
- q_IR: 0.25
- ell_IR: 32
- simulator eta ready: False
- physical CMB prediction: False
