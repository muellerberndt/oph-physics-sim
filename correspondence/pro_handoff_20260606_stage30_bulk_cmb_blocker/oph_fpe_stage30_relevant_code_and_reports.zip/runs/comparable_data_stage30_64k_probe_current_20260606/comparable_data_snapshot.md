# OPH-FPE Comparable Data Snapshot

Comparable-data snapshot for current OPH-FPE receipts. Planck comparisons are shape-only C_l diagnostics with normalized axes and amplitude rescaling. OPH-CMB anomaly-stress adapter values are finite-collar parent diagnostics, not CAMB/CLASS outputs. H3 values are internal modular-response-vs-control receipts. Defect values are screen/collar holonomy proxies. The top-level bulk flag requires every comparable seed in the selected run set to pass the chart/object bulk gate; partial progress is reported by counts. This is not a physical CMB prediction, not a P(k), not a Boltzmann likelihood, and not a completed particle-emergence result.

## Current Answer

Yes: the current simulator can emit diagnostic, measurement-facing values. No: it does not yet emit a physical CMB prediction, physical P(k), populated 3D bulk, or particle spectrum.

## Support-Visible Lorentz Branch

- runs with Lorentz split receipts: 1
- chart-level conformal Lorentz receipts: 1
- BW automorphism sanity receipts: 1
- support-visible 3+1D Lorentz receipts: 1
- endogenous modular-generator receipts: 0
- paper-theorem-assisted populated H3 chart receipts: 0
- object bulk-population receipts: 0
- screen-proxy CMB receipts: 1
- bulk-established count: 0
- interpretation: Splits the paper-side chart-level Lorentz receipt from later strengthening receipts. A support-visible Lorentz count means conformal H3 chart plus direct BW/KMS automorphism sanity; a theorem-assisted populated-chart count means observer objects populate that H3 chart under current controls. This is still separate from the strict finite endogenous-generator bulk proof and from particles/physical cosmology.

## State-Derived BW Matrix Elements

- runs with state-derived BW reports: 1
- endogenous-generator runs: 0
- declared cap-flow generator runs: 0
- declared response-density runs: 0
- direct transition-automorphism runs: 1
- BW/KMS receipts: 1
- density-log calibration receipts: 0
- endogenous correct-beats-controls count: 0
- selected-2pi count: 1
- state-mode counts: {'transition_response_unitary': 1}
- generator-scale counts: {'1': 1}
- best-control counts: {'no_modular_flow': 1}
- generator-scale audit runs: 0
- generator audit configured-best count: 0
- generator audit 2pi-best count: 0
- generator audit best-label counts: {}
- generator audit diagnosis counts: {}
- mean generator-audit best score: n/a
- mean generator-audit configured score: n/a
- mean median residual: 1.609722125e-15
- mean endogenous median residual: n/a
- mean declared cap-flow median residual: n/a
- mean declared response-density median residual: n/a
- mean direct transition median residual: 1.609722125e-15
- mean wrong-1x median: 0.7074113918
- mean wrong-pi median: 0.7626219218
- mean no-modular-flow median: 0.5822545423
- interpretation: Only direct transition-automorphism BW receipts pass in this run set. Those are useful finite support-visible sanity receipts for the declared 2pi transport. They are counted with the conformal H3 chart in the separate Lorentz branch lane; they are not endogenous observer-record modular generators and do not establish a populated bulk.

## Static Galaxy Proxy

- galaxy proxy reports: 1
- proxy receipts: 1
- runs with external RAR/BTFR/disk data: 0
- RAR lambda-fit count: 0
- BTFR fit count: 0
- disk residual count: 0
- mean declared a0_OPH: 1.2e-10
- mean effective a0: 1.2e-10
- mean declared lambda_collar: 1
- mean fitted lambda_collar: n/a
- mean BTFR slope: n/a
- interpretation: Static galaxy lane for OPH RAR/BTFR continuation diagnostics. Current run-bundle outputs are proxy surfaces unless external SPARC/RAR/BTFR rows are supplied, so this is measurement-facing scaffolding rather than a publication-grade galaxy likelihood.

## Static Galaxy Measurement Fit

- external fit reports: 1
- RAR/BTFR receipts: 1
- OPH-CET bridge receipts: 1
- claim-tier counts: {'Tier1_phenomenological_continuation': 1}
- physical-claim fit reports: 1
- physical-CMB claim reports: 0
- bulk-required reports: 0
- mean dataset galaxy count: 175
- mean measurement galaxy count: 175
- mean RAR galaxy count: 1
- mean RAR point count: 2693
- mean RAR scatter dex: 0.1328132048
- mean BTFR slope: 3.486344605
- mean BTFR predicted slope from RAR fit: 4
- mean BTFR slope delta: -0.5136553948
- mean BTFR intercept delta dex: 0.9468738645
- holdout usable reports: 1
- holdout receipts: 1
- mean holdout train/test galaxies: 122 / 53
- mean holdout train/test points: 2316 / 1073
- mean holdout shared a0: 9.453392623e-11
- mean holdout shared lambda_collar: 1.000251915
- mean holdout train log-accel RMSE dex: 0.2050059735
- mean holdout test log-accel RMSE dex: 0.1723922045
- mean holdout test velocity RMSE km/s: 22.68762006
- mean holdout baryon-only velocity RMSE km/s: 59.18159598
- mean holdout velocity RMSE improvement: 0.6166439974
- interpretation: External static-galaxy OPH-CET bridge lane. It calibrates the OPH continuation law on RAR acceleration rows with free a0/lambda_collar and reports the asymptotic BTFR implied by that fit when BTFR rows exist. The optional SPARC mass-model holdout splits by galaxy and fits only shared a0/lambda_collar with fixed M/L assumptions. It is measurement-facing static phenomenology; it does not require the populated-bulk gate and is not a physical CMB/P(k) prediction.

## H3 Modular-Response Receipt

- runs with H3 fits: 1
- H3 receipts: 0
- mean H3 RMSE: 1.005583987
- mean H3 explained variance: -0.01119915481
- H3-chart 3D-window count: 1
- H3-chart estimator-agreement count: 1
- mean H3-chart correlation dimension: 3.097714559
- mean H3-chart local-MLE dimension: 2.889578773
- mean S2-boundary RMSE: 1.000251131
- mean shuffled-response RMSE: 1.005088976
- strict wrong-scale feature audits: 1
- mean wrong-scale feature win fraction: 0.625
- mean 2pi/H3 feature win fraction: 0.375
- wrong-scale red-flag runs: 1
- worst wrong-scale group sample: {'cap_index': 0, 'time_index': 1, 'time': 0.25, 'observable': 'record_family', 'feature_type': 'change_probability_delta', 'feature_count': 1, 'winner_counts': {'2pi_h3_fit': 0, '1x': 0, '4pi': 1, 'pi': 0}, 'wrong_scale_win_fraction': 1.0, 'median_h3_feature_rmse': 0.9999807872878421, 'median_best_wrong_scale_rmse': 0.999673961334016}

## Observer Readout Consensus

- runs with observer readout reports: 1
- mean observer count: 192
- mean overlap pair count: 109
- mean global committed fraction: 1
- mean median overlap Jaccard: 0.1294117647
- mean median signature similarity: 0.6666666667
- mean p10 signature similarity: 0.4166666667
- mean object overlap agreement: 0.5027468264
- mean object p10 overlap agreement: 0.5003623281
- mean counterfactual stability: 1
- bad record rewrite detections: 0

## Observer-Chart Object Population

- runs with object-chart reports: 1
- object-chart receipts: 0
- object-chart median receipts: 0
- localized-object precursor receipts: 0
- bulk-population receipts: 0
- mean object count: 16
- mean localized object count: 8
- mean localized non-boundary object count: 8
- mean shuffle control count: 16
- mean shuffled localized object count: 10
- mean shuffled localized object p90: 11.5
- mean H3 compactness: 0.43597808
- mean S2-boundary compactness: 0.6610620489
- mean shuffled-H3 compactness: 0.2687988798
- mean p10 shuffled-H3 compactness: 0.2266137667
- mean p90 shuffled-H3 compactness: 0.4881709426
- H3 beats median shuffle count: 0
- H3 beats robust shuffle count: 0

## Neutral Observer Reconstruction

- runs with neutral reconstruction reports: 1
- radial-depth-used count: 0
- control-gate passed count: 1
- candidate 3D-window count: 0
- bulk-established count: 0
- estimators-agree count: 0
- mean primary dimension: n/a
- mean correlation dimension: 5.122277497
- mean local-MLE dimension: 6.097471013
- blind usable count: 1
- blind S2-leakage-pass count: 1
- blind candidate 3D-window count: 0
- blind bulk-established count: 0
- mean blind feature width: 55
- mean blind S2-distance correlation: 0.06899444785
- mean blind correlation dimension: 7.455950643
- mean blind local-MLE dimension: 11.06776279

## Planck-Lite Screen C_l Shape

- runs with CMB-lite comparisons: 1
- best-field counts: {'record_signature_smooth_k32': 1}
- best-positive-field counts: {'record_signature_smooth_k32': 1}
- mean best-field correlation: 0.282784909
- mean best-field RMSE: 0.9591833481
- mean best-positive-field correlation: 0.282784909
- mean best-positive-field RMSE: 0.9591833481
- mean record-signature correlation: 0.2370494381
- mean record-signature RMSE: 0.9714975882

## CMB Screen-Basis Transfer

- transfer reports: 1
- diagnostic receipts: 1
- mean train correlation: 0.8767158115
- mean train RMSE: 0.4809891374
- mean test correlation: 0.7772234859
- mean test RMSE: 0.6290909619
- mean max control test correlation: 0.2563442058
- mean test-control correlation gap: 0.5208792801
- mean bootstrap test correlation [p05, p95]: [0.7311693075, 0.8375257992]
- mean bootstrap test RMSE [p05, p95]: [0.4759147795, 0.7418210283]
- interpretation: Cross-scale screen-basis transfer is the strongest current Planck-facing diagnostic. It fits weights using observed Planck TT shape and checks transfer across patch counts against target/field-shuffle controls, so it is useful evidence about screen-statistic structure but not a physical CMB prediction.

## CAMB LambdaCDM Baseline

- baseline reports: 1
- CDM-limit Boltzmann receipts: 1
- OPH anomaly-module-ready reports: 0
- mean shape correlation: 0.9998604572
- mean normalized RMSE: 0.01670585755
- mean amplitude-fit chi2/bin: 0.9444957497
- mean best-fit-column chi2/bin: 0.78459695
- mean first peak ell: 225.164945
- mean benchmark first peak ell: 225.164945
- mean absolute fractional error: 0.01932145262
- interpretation: External LambdaCDM CAMB baseline for CDM-limit/Boltzmann plumbing. This lane should match the local Planck TT benchmark reasonably well and gives us a regression target for any future OPH anomaly module. It is not an OPH prediction because all cosmological parameters are external defaults and no repair/anomaly source term is injected.

## OPH Boltzmann Input Readouts

- input reports: 1
- CDM-limit-ready reports: 1
- diagnostic repair-table-ready reports: 1
- physical-prediction-ready reports: 0
- mean source report count: 1
- mean CDM row count: 4
- mean diagnostic row count: 32
- mean missing gate count: 7
- mean Gamma_rec/H shape proxy: 0.5116542394
- mean B_A shape proxy: 1.380839887e-15
- interpretation: Machine-readable bridge from OPH-CMB diagnostics to future CAMB/CLASS inputs. The CDM-limit rows are solver-ready only as an external LambdaCDM regression target. The repair-exchange rows are finite-collar proxy shapes and remain gated against physical prediction language.

## OPH-CMB Anomaly-Stress Adapter

- adapter reports: 1
- Boltzmann-ready reports: 0
- physical-prediction-ready reports: 0
- cosmology perturbation receipts: 0
- mean finite-collar sample count: 4
- mean weighted collar repair defect R: 1.210304003
- mean rho_A_eq proxy: n/a
- mean diagnostic kernel rows: 4
- mean missing gate count: 15
- interpretation: OPH-CMB adapter lane from the CMB writeup. It preserves standard photon-baryon recombination physics and exposes the OPH anomaly sector quantities needed by a future CAMB/CLASS module. Current values are finite-collar parent diagnostics, not theorem-grade rho_A(a), Gamma_rec, or B_A(k,a), so the Boltzmann gate remains closed.

## Screen Holonomy Defect Proxy

- runs with holonomy reports: 1
- mean defect fraction: 0.8364166667
- mean cluster count: 24

## Defect Worldline / Particle Precursors

- runs with defect-worldline diagnostics: 0
- timeline reports: 0
- interaction reports: 0
- particle-likeness reports: 0
- H3 worldline reports: 0
- screen-worldline precursor receipts: 0
- interaction proxy receipts: 0
- H3 bulk-worldline precursor receipts: 0
- particle-matter receipts: 0
- mean worldline count: n/a
- mean persistent worldline count: n/a
- mean max observation count: n/a
- mean max lifetime cycles: n/a
- mean screen transport proxy count: n/a
- mean fusion candidate count: n/a
- mean particle-like count: n/a

## Output Files

- `comparable_data_snapshot.json`
- `comparable_data_rows.csv`
- `comparable_data_snapshot.md`
