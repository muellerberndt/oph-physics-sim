import numpy as np

from oph_fpe.bulk.cap_geometry import sample_caps
from oph_fpe.bulk.h3_refit import (
    load_modular_response_kernel_cache,
    write_h3_refit_ensemble_report,
    write_h3_refit_report,
    write_modular_response_kernel_cache,
)
from oph_fpe.bulk.h3_response_fit import modular_response_h3_report, synthetic_h3_modular_kernel
from oph_fpe.bulk.modular_response_kernel import kernel_json_summary, modular_response_kernel
from oph_fpe.cache.geometry_cache import GeometryCache
from oph_fpe.core.graph import fibonacci_sphere_points


def test_geometry_cache_reuses_cap_transport_map():
    points = fibonacci_sphere_points(256)
    caps = sample_caps(points, count=2, theta_values=[0.55], seed=1)
    cache = GeometryCache(points)

    first_indices, first_weights = cache.cap_transport_map(caps[0], 0.25, k=1, cap_id=0)
    second_indices, second_weights = cache.cap_transport_map(caps[0], 0.25, k=1, cap_id=0)

    assert first_indices.shape == (256, 1)
    assert np.array_equal(first_indices, second_indices)
    assert np.array_equal(first_weights, second_weights)
    assert cache.report()["transport_map_count"] == 1


def test_modular_response_kernel_shape_and_summary():
    points = fibonacci_sphere_points(512)
    caps = sample_caps(points, count=3, theta_values=[0.55, 0.75], seed=2)
    raw_fields = {
        "record_signature": np.sin(points[:, 0] * 4.0),
        "stable_count": np.cos(points[:, 1] * 5.0),
        "s3_class_density": np.sin(points[:, 2] * 7.0),
    }
    observer_views = [
        {
            "view_type": "patch_observer",
            "observer_id": index,
            "support_nodes": list(range(index, min(index + 16, points.shape[0]))),
        }
        for index in range(0, 128, 16)
    ]

    kernel = modular_response_kernel(
        points,
        caps,
        raw_fields,
        observer_views,
        times=[0.05, 0.1],
        field_names=["record_signature", "stable_count"],
        geometry_cache=GeometryCache(points),
    )
    summary = kernel_json_summary(kernel)

    assert kernel["matrix"].shape == (len(observer_views), 3 * 2 * 2)
    assert kernel["s2_boundary_control"].shape == kernel["matrix"].shape
    assert kernel["shuffled_control"].shape == kernel["matrix"].shape
    assert kernel["no_modular_flow_control"].shape == kernel["matrix"].shape
    assert summary["feature_count"] == 12
    assert summary["geometry_cache"]["transport_map_count"] == 6
    assert 0.0 <= kernel["response_summary"]["min"] <= kernel["response_summary"]["max"] <= 1.0


def test_synthetic_modular_response_h3_receipt_can_pass_controls():
    points = fibonacci_sphere_points(512)
    caps = sample_caps(points, count=10, theta_values=[0.55, 0.75, 1.0], seed=3)
    kernel = synthetic_h3_modular_kernel(
        caps,
        observer_count=18,
        times=[0.05, 0.1],
        field_names=["record_signature", "stable_count"],
        seed=4,
        softness=0.2,
    )

    report = modular_response_h3_report(
        kernel,
        caps,
        candidate_count=4096,
        candidate_radius=1.2,
        softness=0.2,
        seed=4,
        pass_ratio=0.95,
        min_observers=8,
        min_features=12,
    )

    assert report["mode"] == "modular_response_kernel_to_h3_fit"
    assert report["MODULAR_RESPONSE_KERNEL_TO_H3_RECEIPT"] is True
    assert report["claim_level"] == "demo"
    assert report["physical_claim"] is False
    assert report["h3_chart_dimension_debug"]["mode"] == "h3_chart_dimension_debug"


def test_object_transition_kernel_is_signed_and_writes_controls():
    points = fibonacci_sphere_points(512)
    caps = sample_caps(points, count=4, theta_values=[0.55, 0.75], seed=5)
    raw_fields = {
        "record_signature": np.arange(points.shape[0]) % 17,
        "stable_count": (np.arange(points.shape[0]) % 9) + 1,
        "committed_mask": (np.arange(points.shape[0]) % 3 == 0).astype(float),
        "repair_load": np.abs(points[:, 0]),
        "s3_sector_class": np.arange(points.shape[0]) % 6,
    }
    observer_views = [
        {
            "view_type": "patch_observer",
            "observer_id": index,
            "axis": [float(value) for value in points[index]],
            "support_nodes": list(range(index, min(index + 24, points.shape[0]))),
        }
        for index in range(0, 192, 24)
    ]

    kernel = modular_response_kernel(
        points,
        caps,
        raw_fields,
        observer_views,
        times=[0.125, 0.25],
        observable_mode="object_transition",
        transition_observables=["checkpoint_class", "record_family", "s3_sector_class"],
        transform="signed_zscore",
        geometry_cache=GeometryCache(points),
        wrong_scales=[1.0, np.pi],
    )

    assert kernel["observable_mode"] == "object_transition"
    assert kernel["matrix"].shape[0] == len(observer_views)
    assert kernel["matrix"].shape == kernel["no_modular_flow_control"].shape
    assert kernel["matrix"].shape == kernel["s2_boundary_control"].shape
    assert "1x" in kernel["wrong_scale_controls"]
    assert "pi" in kernel["wrong_scale_controls"]
    assert abs(float(np.mean(kernel["matrix"]))) < 1e-9
    assert kernel["response_summary"]["std"] > 0.1


def test_perturb_resettle_transition_kernel_uses_graph_state():
    points = fibonacci_sphere_points(512)
    caps = sample_caps(points, count=3, theta_values=[0.55, 0.75], seed=8)
    left = np.arange(0, 256, dtype=np.int64)
    right = (left + 7) % points.shape[0]
    port_left = (np.arange(left.size) % 6).astype(np.int16)
    port_right = ((np.arange(left.size) + 1) % 6).astype(np.int16)
    raw_fields = {
        "record_signature": np.arange(points.shape[0]) % 19,
        "stable_count": (np.arange(points.shape[0]) % 11) + 1,
        "committed_mask": (np.arange(points.shape[0]) % 2 == 0).astype(float),
        "repair_load": np.abs(points[:, 1]),
        "cumulative_repair_load": np.abs(points[:, 2]),
        "s3_sector_class": np.arange(points.shape[0]) % 6,
    }
    observer_views = [
        {
            "view_type": "patch_observer",
            "observer_id": index,
            "axis": [float(value) for value in points[index]],
            "support_nodes": list(range(index, min(index + 24, points.shape[0]))),
        }
        for index in range(0, 192, 24)
    ]

    kernel = modular_response_kernel(
        points,
        caps,
        raw_fields,
        observer_views,
        times=[0.125, 0.25],
        observable_mode="perturb_resettle_transition",
        transition_observables=["checkpoint_class", "record_family", "repair_load_bucket"],
        transform="signed_zscore",
        graph_state={
            "left": left,
            "right": right,
            "port_left": port_left,
            "port_right": port_right,
            "group_order": 6,
            "patch_count": points.shape[0],
        },
        perturb_strength=1.0,
        perturb_budget_mode="fixed_collar_fraction",
        fixed_perturb_fraction=0.25,
        perturb_selection_mode="lambda_displacement",
        repair_steps=2,
        repairs_per_step=32,
        perturb_seed=9,
        wrong_scales=[1.0, np.pi, 2.0 * np.pi],
    )

    assert kernel["observable_mode"] == "perturb_resettle_transition"
    assert kernel["matrix"].shape[0] == len(observer_views)
    assert kernel["matrix"].shape == kernel["no_modular_flow_control"].shape
    assert "perturb_resettle_report" in kernel
    assert kernel["perturb_resettle_report"]["perturb_selection_mode"] == "lambda_displacement"
    assert kernel["perturb_resettle_report"]["perturb_budget_mode"] == "fixed_collar_fraction"
    assert kernel["perturb_resettle_report"]["transition_readout_mode"] == "same_support"
    assert np.allclose(kernel["wrong_scale_controls"]["2pi"], kernel["matrix"])
    assert kernel["raw_response_summary"]["std"] > 0.0
    assert kernel["response_summary"]["std"] > 0.0


def test_perturb_resettle_can_read_transported_observer_supports():
    points = fibonacci_sphere_points(512)
    caps = sample_caps(points, count=2, theta_values=[0.75], seed=88)
    left = np.arange(0, 384, dtype=np.int64)
    right = (left + 11) % points.shape[0]
    port_left = (np.arange(left.size) % 6).astype(np.int16)
    port_right = ((np.arange(left.size) + 2) % 6).astype(np.int16)
    raw_fields = {
        "record_signature": np.arange(points.shape[0]) % 23,
        "stable_count": (np.arange(points.shape[0]) % 13) + 1,
        "committed_mask": (np.arange(points.shape[0]) % 2 == 0).astype(float),
        "repair_load": np.abs(points[:, 0]),
        "cumulative_repair_load": np.abs(points[:, 1]),
        "s3_sector_class": np.arange(points.shape[0]) % 6,
    }
    observer_views = [
        {
            "view_type": "patch_observer",
            "observer_id": index,
            "axis": [float(value) for value in points[index]],
            "support_nodes": list(range(index, min(index + 32, points.shape[0]))),
        }
        for index in range(0, 256, 32)
    ]

    kernel = modular_response_kernel(
        points,
        caps,
        raw_fields,
        observer_views,
        times=[0.2],
        observable_mode="perturb_resettle_transition",
        transition_observables=["checkpoint_class", "record_family", "repair_load_bucket"],
        transform="signed_zscore",
        graph_state={
            "left": left,
            "right": right,
            "port_left": port_left,
            "port_right": port_right,
            "group_order": 6,
            "patch_count": points.shape[0],
        },
        perturb_strength=1.0,
        perturb_budget_mode="fixed_collar_fraction",
        fixed_perturb_fraction=0.25,
        perturb_selection_mode="lambda_displacement",
        transition_readout_mode="transported_support",
        repair_steps=2,
        repairs_per_step=32,
        perturb_seed=89,
        wrong_scales=[1.0, 2.0 * np.pi],
    )

    assert kernel["observable_mode"] == "perturb_resettle_transition"
    assert kernel["perturb_resettle_report"]["transition_readout_mode"] == "transported_support"
    assert np.allclose(kernel["wrong_scale_controls"]["2pi"], kernel["matrix"])
    assert not np.allclose(kernel["wrong_scale_controls"]["1x"], kernel["matrix"])
    assert kernel["raw_response_summary"]["std"] > 0.0


def test_transition_response_alias_uses_perturb_resettle_kernel():
    points = fibonacci_sphere_points(192)
    caps = sample_caps(points, count=1, theta_values=[0.55], seed=10)
    left = np.arange(0, 96, dtype=np.int64)
    right = (left + 5) % points.shape[0]
    raw_fields = {
        "record_signature": np.arange(points.shape[0]) % 11,
        "stable_count": (np.arange(points.shape[0]) % 7) + 1,
        "committed_mask": (np.arange(points.shape[0]) % 2 == 0).astype(float),
        "repair_load": np.abs(points[:, 0]),
        "s3_sector_class": np.arange(points.shape[0]) % 6,
    }
    observer_views = [
        {
            "view_type": "patch_observer",
            "observer_id": index,
            "axis": [float(value) for value in points[index]],
            "support_nodes": list(range(index, min(index + 12, points.shape[0]))),
        }
        for index in range(0, 96, 12)
    ]

    kernel = modular_response_kernel(
        points,
        caps,
        raw_fields,
        observer_views,
        times=[0.125],
        observable_mode="transition_response",
        transition_observables=["checkpoint_class", "record_family"],
        transform="signed_zscore",
        graph_state={
            "left": left,
            "right": right,
            "port_left": (np.arange(left.size) % 6).astype(np.int16),
            "port_right": ((np.arange(left.size) + 1) % 6).astype(np.int16),
            "group_order": 6,
            "patch_count": points.shape[0],
        },
        repair_steps=1,
        repairs_per_step=16,
    )

    assert kernel["observable_mode"] == "perturb_resettle_transition"
    assert kernel["matrix"].shape[0] == len(observer_views)
    assert kernel["transform_report"]["mode"] == "signed_zscore"


def test_synthetic_modular_response_joint_h3_receipt_can_pass_controls():
    points = fibonacci_sphere_points(512)
    caps = sample_caps(points, count=12, theta_values=[0.55, 0.75, 1.0], seed=6)
    kernel = synthetic_h3_modular_kernel(
        caps,
        observer_count=24,
        times=[0.05, 0.1],
        field_names=["record_signature", "stable_count"],
        seed=7,
        softness=0.2,
    )
    matrix = np.asarray(kernel["matrix"], dtype=float)
    kernel["wrong_scale_controls"] = {
        "1x": 0.5 * np.ones_like(matrix),
        "pi": np.flip(matrix, axis=1),
    }

    report = modular_response_h3_report(
        kernel,
        caps,
        candidate_count=4096,
        candidate_radius=1.2,
        softness=0.2,
        seed=7,
        pass_ratio=0.95,
        min_observers=8,
        min_features=12,
        fit_mode="joint_global",
        anchor_weight=0.0,
        max_iterations=3,
        control_fit_mode="affine_target_fit",
    )

    assert report["fit_mode"] == "joint_global"
    assert report["MODULAR_RESPONSE_KERNEL_TO_H3_RECEIPT"] is True
    assert report["h3_fit"]["heldout_normalized_rmse"] < report["s2_boundary_control"]["heldout_normalized_rmse"]
    assert report["h3_chart_dimension_debug"]["point_count"] == 24
    assert report["wrong_scale_feature_audit"]["eligible"] is True
    assert report["wrong_scale_feature_audit"]["audited_feature_count"] > 0
    assert "2pi_h3_fit" in report["wrong_scale_feature_audit"]["winner_counts"]
    assert "2pi_h3_fit" in report["wrong_scale_feature_audit"]["material_winner_counts"]
    assert report["wrong_scale_feature_audit"]["material_margin"] == 0.01
    assert report["wrong_scale_feature_audit"]["worst_groups"]


def test_modular_response_h3_feature_selection_filters_dead_columns():
    points = fibonacci_sphere_points(512)
    caps = sample_caps(points, count=10, theta_values=[0.55, 0.75, 1.0], seed=16)
    kernel = synthetic_h3_modular_kernel(
        caps,
        observer_count=24,
        times=[0.05, 0.1],
        field_names=["record_signature", "stable_count"],
        seed=17,
        softness=0.2,
    )
    matrix = kernel["matrix"]
    dead = np.zeros((matrix.shape[0], 20), dtype=float)
    kernel["matrix"] = np.hstack([matrix, dead])
    kernel["s2_boundary_control"] = np.hstack([kernel["s2_boundary_control"], dead])
    kernel["shuffled_control"] = np.hstack([kernel["shuffled_control"], dead])
    kernel["no_modular_flow_control"] = np.hstack([kernel["no_modular_flow_control"], dead])
    for index in range(dead.shape[1]):
        kernel["feature_rows"].append(
            {
                "feature_index": len(kernel["feature_rows"]),
                "cap_index": 0,
                "time_index": 0,
                "time": 0.0,
                "field": f"dead_{index}",
            }
        )

    report = modular_response_h3_report(
        kernel,
        caps,
        candidate_count=4096,
        candidate_radius=1.2,
        softness=0.2,
        seed=17,
        pass_ratio=0.95,
        min_observers=8,
        min_features=12,
        fit_mode="joint_global",
        anchor_weight=0.0,
        max_iterations=3,
        feature_selection="variance",
        max_fit_features=24,
        min_feature_std=1.0e-4,
    )

    assert report["feature_selection"]["mode"] == "variance"
    assert report["feature_selection"]["original_feature_count"] == matrix.shape[1] + 20
    assert report["feature_selection"]["selected_feature_count"] == 24
    assert report["feature_count"] == 24
    assert report["MODULAR_RESPONSE_KERNEL_TO_H3_RECEIPT"] is True


def test_modular_response_h3_feature_selection_can_keep_change_probability_only():
    points = fibonacci_sphere_points(512)
    caps = sample_caps(points, count=8, theta_values=[0.55, 0.75, 1.0], seed=26)
    kernel = synthetic_h3_modular_kernel(
        caps,
        observer_count=24,
        times=[0.05, 0.1],
        field_names=["record_signature", "stable_count"],
        seed=27,
        softness=0.2,
    )
    for index, row in enumerate(kernel["feature_rows"]):
        row["observable"] = str(row.get("field", "record_signature"))
        row["feature_type"] = "change_probability_delta" if index % 2 == 0 else "target_distribution_delta"
        row["target_class"] = None if index % 2 == 0 else 0

    report = modular_response_h3_report(
        kernel,
        caps,
        candidate_count=1024,
        candidate_radius=1.2,
        softness=0.2,
        seed=27,
        pass_ratio=1.0,
        min_observers=8,
        min_features=4,
        fit_mode="joint_global",
        anchor_weight=0.0,
        max_iterations=2,
        feature_selection="change_probability_only",
    )

    assert report["feature_selection"]["mode"] == "change_probability_only"
    assert report["feature_selection"]["metadata_filter"] == "feature_type=change_probability_delta"
    assert report["feature_selection"]["selected_feature_count"] == len(kernel["feature_rows"]) // 2
    assert all(
        row["feature_type"] == "change_probability_delta"
        for row in report["feature_rows_sample"]
    )


def test_modular_response_kernel_cache_roundtrips_and_refits(tmp_path):
    points = fibonacci_sphere_points(512)
    caps = sample_caps(points, count=8, theta_values=[0.55, 0.75, 1.0], seed=31)
    kernel = synthetic_h3_modular_kernel(
        caps,
        observer_count=24,
        times=[0.05, 0.1],
        field_names=["record_signature", "stable_count"],
        seed=32,
        softness=0.2,
    )
    cache_report = write_modular_response_kernel_cache(tmp_path, kernel, caps)
    loaded_kernel, loaded_caps, metadata = load_modular_response_kernel_cache(tmp_path)

    assert cache_report["observer_count"] == 24
    assert loaded_kernel["matrix"].shape == kernel["matrix"].shape
    assert loaded_kernel["wrong_scale_controls"] == {}
    assert len(loaded_caps) == len(caps)
    assert metadata["feature_rows"][0]["cap_index"] == 0

    out = tmp_path / "refit.json"
    report = write_h3_refit_report(
        tmp_path,
        out,
        candidate_count=2048,
        candidate_radius=1.2,
        softness=0.2,
        seed=32,
        pass_ratio=0.95,
        min_observers=8,
        min_features=12,
        fit_mode="joint_global",
        anchor_weight=0.0,
        max_iterations=3,
    )

    assert out.exists()
    assert report["MODULAR_RESPONSE_KERNEL_TO_H3_RECEIPT"] is True
    assert report["kernel_cache"]["observer_count"] == 24


def test_h3_refit_seed_ensemble_reports_robustness(tmp_path):
    points = fibonacci_sphere_points(512)
    caps = sample_caps(points, count=8, theta_values=[0.55, 0.75, 1.0], seed=41)
    kernel = synthetic_h3_modular_kernel(
        caps,
        observer_count=24,
        times=[0.05, 0.1],
        field_names=["record_signature", "stable_count"],
        seed=42,
        softness=0.2,
    )
    write_modular_response_kernel_cache(tmp_path, kernel, caps)

    report = write_h3_refit_ensemble_report(
        tmp_path,
        tmp_path / "ensemble.json",
        seeds=[42, 43, 44],
        required_receipt_fraction=0.5,
        candidate_count=2048,
        candidate_radius=1.2,
        softness=0.2,
        pass_ratio=0.95,
        min_observers=8,
        min_features=12,
        fit_mode="joint_global",
        anchor_weight=0.0,
        max_iterations=3,
    )

    assert report["mode"] == "h3_refit_seed_ensemble"
    assert report["seed_count"] == 3
    assert report["receipt_count"] >= 1
    assert report["h3_response_seed_robust_receipt"] is True
    assert report["physical_claim"] is False


def test_joint_h3_fit_local_refinement_is_fair_to_controls():
    points = fibonacci_sphere_points(512)
    caps = sample_caps(points, count=8, theta_values=[0.55, 0.75, 1.0], seed=51)
    kernel = synthetic_h3_modular_kernel(
        caps,
        observer_count=24,
        times=[0.05, 0.1],
        field_names=["record_signature", "stable_count"],
        seed=52,
        softness=0.2,
    )

    report = modular_response_h3_report(
        kernel,
        caps,
        candidate_count=512,
        candidate_radius=1.2,
        softness=0.2,
        seed=52,
        pass_ratio=0.95,
        min_observers=8,
        min_features=12,
        fit_mode="joint_global",
        anchor_weight=0.0,
        max_iterations=2,
        refine_steps=1,
        refine_max_rows=8,
        refine_max_nfev=8,
    )

    assert report["h3_fit"]["refinement"]["enabled"] is True
    assert "shuffled_response" in report["control_fits"]
    assert report["control_fits"]["shuffled_response"]["refinement"]["enabled"] is True


def test_joint_h3_fit_can_use_deterministic_candidate_ball():
    points = fibonacci_sphere_points(512)
    caps = sample_caps(points, count=8, theta_values=[0.55, 0.75, 1.0], seed=61)
    kernel = synthetic_h3_modular_kernel(
        caps,
        observer_count=24,
        times=[0.05, 0.1],
        field_names=["record_signature", "stable_count"],
        seed=62,
        softness=0.2,
    )

    report = modular_response_h3_report(
        kernel,
        caps,
        candidate_count=1024,
        candidate_radius=1.2,
        softness=0.2,
        seed=62,
        pass_ratio=0.95,
        min_observers=8,
        min_features=12,
        fit_mode="joint_global",
        anchor_weight=0.0,
        max_iterations=3,
        candidate_mode="fibonacci_ball",
    )

    assert report["h3_fit"]["candidate_mode"] == "fibonacci_ball"
    assert report["h3_fit"]["assignment_unique_count"] > 0
    assert report["MODULAR_RESPONSE_KERNEL_TO_H3_RECEIPT"] is True
